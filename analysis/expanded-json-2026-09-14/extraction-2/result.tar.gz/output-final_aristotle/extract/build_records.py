#!/usr/bin/env python3
"""Build records.json and exceptions.json from the two source documents in task.json.

Every evidence quote is checked to be an exact, nonempty substring of the cited
source text before the files are written.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

with open(os.path.join(ROOT, "task.json"), encoding="utf-8") as fh:
    TASK = json.load(fh)

SRC = {s["id"]: s["text"] for s in TASK["source_excerpts"]}
M, Q = SRC["M"], SRC["Q"]
QUERIES = {q["id"]: q for q in TASK["queries"]}


def qline(label):
    """Return the full source line of Q carrying \\label{ex:LABEL}."""
    for line in Q.split("\n"):
        if "\\label{ex:%s}" % label in line:
            return line
    raise KeyError(label)


def qrow(expr):
    """Return the comparison-table row of Q for an expression."""
    for line in Q.split("\n"):
        if line.startswith("\\mention{%s} &" % expr):
            return line
    raise KeyError(expr)


def ev(source_id, quote):
    return {"source_id": source_id, "quote": quote}


def cond(bearer, requirement):
    return {"bearer": bearer, "requirement": requirement}


# ---------------------------------------------------------------- lexemes ---
# Forms are those the two documents exhibit for each lexeme; paradigm-mates are
# included only where a document states that they belong to the same lexeme.
LEXEME_FORMS = {
    "lex_the": ["the"],
    "lex_every": ["every"],
    "lex_some": ["some"],
    "lex_few": ["few", "fewer", "fewest"],
    "lex_no": ["no", "none"],
    "lex_my": ["my", "mine"],
    "lex_book": ["book", "books"],
    "lex_a": ["a"],
    "lex_many": ["many", "more", "most"],
    "lex_much": ["much"],
    "lex_little": ["little"],
    "lex_several": ["several"],
    "lex_all": ["all"],
    "lex_both": ["both"],
    "lex_any": ["any"],
    "lex_enough": ["enough"],
    "lex_this": ["this", "these"],
    "lex_that": ["that", "those"],
    "lex_anyone": ["anyone"],
    "lex_something": ["something"],
    "lex_certain": ["certain"],
    "lex_various": ["various"],
    "lex_numerous": ["numerous"],
    "lex_multiple": ["multiple"],
    "lex_countless": ["countless"],
    "lex_plenty": ["plenty"],
    "lex_lot": ["lot"],
    "lex_lots": ["lots"],
    "lex_heaps": ["heaps"],
    "lex_deal": ["deal"],
    "lex_ten": ["ten"],
    "lex_thirty": ["thirty"],
    "lex_rich": ["rich"],
    "lex_second": ["second"],
}

lexemes = [{"id": lid, "forms": LEXEME_FORMS[lid]} for lid in TASK["lexeme_ids"]]

# ----------------------------------------------------------- constructions ---
constructions = [
    {"id": cid, "description": desc}
    for cid, desc in TASK["construction_catalog"].items()
]

# ------------------------------------------------- shared supplement quotes ---
Q_CAPTION = ("G: described in \\textit{CGEL}; R: restricted there; \\textit{I}: "
             "constructed positive illustration in the stated frame. Numbered "
             "references identify attestations below. S: searched, with no "
             "qualifying attestation retained; this isn't an ungrammaticality "
             "judgment.")
Q_FRAMES = ("The argument frames are \\mention{X of them}, \\mention{X who arrived "
            "left}, and anaphoric \\mention{X left}. The existential frames are "
            "\\mention{There are X of them}, \\mention{There are X who can help}, "
            "and anaphoric \\mention{Are there X?}")
Q_PEOPLE = "Interpret the constructed comparisons with people under discussion."
Q_PREP = "Argument use also includes complementation of prepositions."
Q_LOT_A = "The common-noun controls retain \\mention{a} in \\mention{a lot}."
Q_SEP = "Table~\\ref{tab:quant-controls} separates NP dependents from the surrounding construction."
Q_ORDERING = ("The searches establish selected occurrences, without estimating "
              "their frequency or establishing an ordering of the constructions.")
Q_RATES = "These searches establish selected occurrences; they supply no usage rates."
Q_VARIETY = ("Source locations identify the records; they don't establish each "
             "speaker's or writer's variety.")
Q_GR = ("The G and R cells retain the qualifications just stated; the common-noun "
        "partitives follow \\textit{CGEL}")
Q_CGEL_RESTR = ("The \\mention{of}-phrase with independent \\mention{certain} and "
                "\\mention{various} is hardly omissible. The partitive with "
                "\\mention{certain} is relatively formal; that with \\mention{various} "
                "is accepted by some speakers, primarily in American English")
Q_CGEL_SEVERAL = ("includes \\mention{several} among determinatives and treats "
                  "quantificational \\mention{certain} and \\mention{various} as marginal "
                  "members.")
Q_MANY_REL = ("The relative use of \\mention{many} follows \\textit{CGEL}'s discussion "
              "of the human interpretation")
Q_NONFINDING = ("No qualifying attestation was retained for four cells: argument "
                "\\mention{certain} with a relative, bare existential \\mention{certain}, "
                "and existential \\mention{various} with a relative or without a "
                "dependent. The bounded searches don't establish exclusion. These cells "
                "retain a different evidential status from the positive examples and "
                "from \\textit{CGEL}'s stated restrictions.")
Q_EXPANDED = ("Expanded contexts exclude overt following nouns, predicative inversions, "
              "and mathematical \\mention{multiple}.")
Q_SEARCHDATE = ("Searches conducted on 12--13 September 2026 in "
                "\\href{https://www.english-corpora.org/now/}{NOW} and "
                "\\href{https://www.english-corpora.org/coca/}{COCA}, using surface "
                "strings without part-of-speech filters.")

BASIS_TEXT = {
    "G": ("Evidential basis stated in the supplement's comparison table: G, "
          "\"described in \\textit{CGEL}\"; the cell records a description, not a "
          "retained attestation."),
    "I": ("Evidential basis stated in the supplement's comparison table: \\textit{I}, "
          "a \"constructed positive illustration in the stated frame\"; the cell "
          "records a constructed comparison, not a retained attestation."),
    "R": ("Evidential basis stated in the supplement's comparison table: R, "
          "\"restricted there\", i.e. restricted in \\textit{CGEL}; a stated "
          "restriction, not an exclusion and not an attestation."),
    "A": ("Evidential basis stated in the supplement's comparison table: a numbered "
          "reference to a retained attestation listed in the supplement."),
}

FRAME_TEXT = [
    "Surrounding construction: argument use; stated frame \"{x} of them\", with the partitive of-PP as the NP dependent. Argument use also includes complementation of prepositions.",
    "Surrounding construction: argument use; stated frame \"{x} who arrived left\", with a relative clause as the NP dependent.",
    "Surrounding construction: argument use, anaphoric, with no NP dependent; stated frame \"{x} left\".",
    "Surrounding construction: existential with dummy \\textit{there} as subject; stated frame \"There are {x} of them\", with the partitive of-PP as the NP dependent.",
    "Surrounding construction: existential with dummy \\textit{there} as subject; stated frame \"There are {x} who can help\", with a relative clause as the NP dependent.",
    "Surrounding construction: existential with dummy \\textit{there} as subject, anaphoric, with no NP dependent; stated frame \"Are there {x}?\".",
]

# expression -> (table row label, lexeme, frame filler, six cell bases)
ROWS = [
    ("many", "lex_many", "many", ["G", "G", "G", "I", "I", "I"]),
    ("several", "lex_several", "several", ["G", "I", "G", "I", "I", "I"]),
    ("certain", "lex_certain", "certain",
     ["G", "S", "R", "ex:certain-exist-part", "ex:certain-exist", "S"]),
    ("various", "lex_various", "various",
     ["G", "ex:various-arg-rel", "R", "ex:various-exist-part", "S", "S"]),
    ("numerous", "lex_numerous", "numerous",
     ["ex:numerous-part", "ex:numerous-arg-rel", "ex:numerous-subj",
      "ex:numerous-exist-part", "ex:numerous-exist", "ex:numerous-exist-bare"]),
    ("multiple", "lex_multiple", "multiple",
     ["ex:multiple-part", "ex:multiple-arg-rel", "ex:multiple-subj",
      "ex:multiple-exist-part", "ex:multiple-exist-rel", "ex:multiple-bare"]),
    ("countless", "lex_countless", "countless",
     ["ex:countless-part", "ex:countless-arg-rel", "ex:countless-subj",
      "ex:countless-exist-part", "ex:countless-exist-rel", "ex:countless-exist-bare"]),
    ("a lot", "lex_lot", "a lot", ["G", "I", "I", "I", "I", "I"]),
    ("plenty", "lex_plenty", "plenty", ["G", "I", "I", "I", "I", "I"]),
]

COL_CONSTRUCTION = [
    "independent_partitive", "independent_argument", "independent_argument",
    "existential_displaced_subject", "existential_displaced_subject",
    "existential_displaced_subject",
]

# Provenance and verification limits, keyed by query id, for attestation cells.
PROVENANCE = {
    "X016": ("Retained attestation \"There are certain of our friends.\": Sharad Pawar, "
             "quoted in English by Manish Tewari in the Deccan Chronicle, 8 July 2018; "
             "NOW record dated 7 July and original article. Stated verification limits: "
             "the original speech language and audio weren't checked."),
    "X017": ("Retained attestation \"there are certain who would not like\": Donald Trump, "
             "as quoted in Fox News, 25 March 2020; NOW record dated 26 March and original "
             "article. Stated verification limit: the quotation was checked against the "
             "article, without an audio check."),
    "X020": ("Retained attestation \"think about various who had done it and who hadn't\": "
             "Stephen Tompkinson, quoted by James Hibbs in the Radio Times, 29 April 2026; "
             "NOW and original interview; the context concerns identifying killers in "
             "detective scripts. Stated verification limit: no audio check."),
    "X022": ("Retained attestation \"There are various of Maro's own inventions\": Erica "
             "Platter, Daily Maverick, 8 March 2019; NOW and original article; the context "
             "lists cakes, with supplementary examples following the partitive."),
    "X025": ("Retained attestation \"numerous of its inhabitants\": Norman Harrington, New "
             "York Times, 7 April 1968, as quoted in Merriam-Webster's Dictionary of English "
             "Usage and reproduced in Reynolds and Pullum's \"New members of closed classes "
             "in English\", §2.1.2. Stated verification route and limit: verified through "
             "that draft; the newspaper original wasn't checked."),
    "X026": ("Retained attestation \"he has heard from numerous who are 'deeply concerned'\": "
             "ABC News, 18 August 2020; NOW record dated 19 August and original "
             "article; the antecedent is Republican attorneys."),
    "X027": ("Retained attestation \"numerous were injured\": Page Six, 4 July 2022; NOW "
             "expanded context; the clause follows a coordinated clause about people who "
             "died, and \\mention{numerous} is the canonical subject."),
    "X028": ("Retained attestation \"There are numerous of them.\": Sunday Cyriacus Umeha, "
             "interviewed by Adamu Abuh in The Guardian (Nigeria), 7 June 2025; NOW and "
             "original interview; the antecedent is people from Enugu appointed to government "
             "positions."),
    "X029": ("Retained attestation \"there are numerous who are willing to donate\": Nana "
             "Patekar, as quoted in English by IANS in The Indian Express, 19 September 2015; "
             "NOW and original article. Stated verification limit: the original language of "
             "the speech wasn't established."),
    "X030": ("Retained attestation \"I'm aware there are numerous.\": Danny Sapio, The Next "
             "Web, 15 December 2019; NOW record dated 29 December and original article, "
             "syndicated from uxdesign.cc; in this cell \\mention{numerous} refers to benefits "
             "of a college education, an anaphoric interpretation established without an "
             "overt following nominal."),
    "X031": ("Retained attestation \"multiple of the fast casual eateries\": COCA, 2012 blog "
             "discussion under \"BurgerFi Bringing Its Burgers to...\"; the surrounding phrase "
             "is \"in front of multiple of the fast casual eateries\". Expanded corpus context "
             "and source metadata checked; stated verification limit: the original page wasn't "
             "available. The retained material excludes mathematical \\mention{multiple}."),
    "X032": ("Retained attestation \"according to multiple who have spoken to him\": The London "
             "Free Press, NOW record dated 19 November 2018, on recruiting campaign staff; "
             "concordance and source metadata checked; stated verification limit: the original "
             "page wasn't available."),
    "X033": ("Retained attestation \"multiple were injured\": Ivana Saric and Herb Scribner, "
             "Axios, 27 June 2022, opening sentence; the original page was checked."),
    "X034": ("Retained attestation \"there are multiple of them\": Ivan Mehta, TechCrunch, "
             "16 September 2022; NOW and original article; the antecedent is objects in a photo."),
    "X035": ("Retained attestation \"There are multiple that are cited in my response.\": "
             "Zachary Loyed, public-records hearing, State of Florida v. Thomas Lee Gudinas, "
             "29 May 2025, transcript p. 7, lines 14--15; Appendix C, PDF p. 55; the original "
             "transcript was checked, and \\mention{multiple} refers to cases."),
    "X036": ("Retained attestation \"are there multiple?\": Kira Bindrim, in a Quartz podcast "
             "transcript, 2022; NOW and original transcript; the preceding question introduces "
             "wedding dresses. Stated discrepancy: NOW dates the record 22 February, while the "
             "current page reports an update on 20 July."),
    "X037": ("Retained attestation \"countless of their particular statements and deeds\": "
             "Thomas Hughson, \"Interpreting Vatican II: 'A New Pentecost'\", Theological "
             "Studies 69 (2008), p. 9; COCA academic record, checked against the journal PDF; "
             "the NP is object of \\mention{irradiate}, and the supplement notes that this "
             "partitive comes from academic prose."),
    "X038": ("Retained attestation \"paving the way for countless who followed him\": WFTV, "
             "NOW record dated 7 January 2022, on Sidney Poitier; concordance and source "
             "metadata checked; stated verification limit: the original URL returned an error "
             "page."),
    "X039": ("Retained attestation \"countless were left in floods of tears\": John Murphy, "
             "Extra.ie, 17 April 2022; NOW and original article; the preceding clause mentions "
             "viewers of \\textit{DIY SOS}, which supplies the interpretation."),
    "X040": ("Retained attestation \"There are countless of them out there\": \"Facebook's "
             "Future Is Brighter Than Ever\", Seeking Alpha, 25 May 2020; NOW expanded context "
             "and source metadata; the antecedent is payment apps."),
    "X041": ("Retained attestation \"There are countless who have greatly impacted their "
             "communities\": \"The Sisterhood List\", Metro, 1 October 2023; NOW expanded "
             "context and source metadata."),
    "X042": ("Retained attestation \"In fact, there are countless.\": Financial Post, NOW "
             "record dated 3 August 2013; complete sentence and adjacent context checked in "
             "the concordance; stated verification limit: the original page wasn't available. "
             "In this cell \\mention{countless} refers to investment options, an anaphoric "
             "interpretation established without an overt following nominal."),
}

participation = []
qid_num = 1
for expr, lex, filler, bases in ROWS:
    for col in range(6):
        qid = "X%03d" % qid_num
        qid_num += 1
        basis = bases[col]
        conds = []
        evs = []
        if basis == "S":
            status = "not_stated"
        else:
            status = "licensed"
            conds.append(cond("construction", FRAME_TEXT[col].replace("{x}", filler)))
            if basis.startswith("ex:"):
                conds.append(cond("construction", BASIS_TEXT["A"]))
                conds.append(cond("construction", PROVENANCE[qid]))
                conds.append(cond("construction",
                                  "Scope of the finding: the supplement's searches establish "
                                  "selected occurrences and supply no usage rates, establish no "
                                  "ordering of the constructions, and don't establish each "
                                  "speaker's or writer's variety; the attestation is evidence "
                                  "for the occurrence, not for the population."))
                evs.append(ev("Q", qline(basis.split(":", 1)[1])))
                evs.append(ev("Q", Q_RATES))
                evs.append(ev("Q", Q_VARIETY))
                evs.append(ev("Q", Q_SEARCHDATE))
            else:
                conds.append(cond("construction", BASIS_TEXT[basis]))
            if basis == "I":
                conds.append(cond("construction",
                                  "The constructed comparison is to be interpreted with people "
                                  "under discussion."))
            evs.append(ev("Q", qrow(expr)))
            evs.append(ev("Q", Q_CAPTION))
            evs.append(ev("Q", Q_FRAMES))
            if basis in ("G", "R"):
                evs.append(ev("Q", Q_GR))
            if basis == "I":
                evs.append(ev("Q", Q_PEOPLE))
            if col in (0, 1, 2):
                evs.append(ev("Q", Q_PREP))
        if lex in ("lex_certain", "lex_various") and status == "licensed":
            if col == 0:
                if lex == "lex_certain":
                    conds.append(cond("own_phrase",
                                      "\\textit{CGEL} qualification carried into this cell: the "
                                      "partitive with \\mention{certain} is relatively formal. "
                                      "This is a register restriction on the partitive use, not "
                                      "an exclusion, and it is not generalized beyond this cell."))
                else:
                    conds.append(cond("own_phrase",
                                      "\\textit{CGEL} qualification carried into this cell: the "
                                      "partitive with \\mention{various} is accepted by some "
                                      "speakers, primarily in American English. This is a speaker "
                                      "and variety restriction, not an exclusion, and it is not "
                                      "generalized beyond this cell."))
                conds.append(cond("own_phrase",
                                  "\\textit{CGEL} treats quantificational \\mention{certain} and "
                                  "\\mention{various} as marginal members of the determinative "
                                  "category."))
                evs.append(ev("Q", Q_CGEL_RESTR))
                evs.append(ev("Q", Q_CGEL_SEVERAL))
            if col == 2:
                conds.append(cond("own_phrase",
                                  "\\textit{CGEL}-stated restriction carried as a restriction: the "
                                  "\\mention{of}-phrase with independent \\mention{certain} and "
                                  "\\mention{various} is hardly omissible. Recorded here as a "
                                  "condition on the no-dependent use, not as a categorical ban; "
                                  "the fixed status vocabulary cannot itself express this R cell "
                                  "(see exceptions.json)."))
                evs.append(ev("Q", Q_CGEL_RESTR))
        if lex == "lex_several" and col == 0 and status == "licensed":
            conds.append(cond("own_phrase",
                              "\\textit{CGEL} includes \\mention{several} among determinatives; "
                              "this cell records that description."))
            evs.append(ev("Q", Q_CGEL_SEVERAL))
        if lex == "lex_many" and col == 1:
            conds.append(cond("construction",
                              "The relative use of \\mention{many} follows \\textit{CGEL}'s "
                              "discussion of the human interpretation, so the cell carries that "
                              "interpretive condition."))
            evs.append(ev("Q", Q_MANY_REL))
        if lex == "lex_multiple" and status == "licensed":
            conds.append(cond("construction",
                              "Expanded contexts for the retained material exclude overt following "
                              "nouns, predicative inversions, and mathematical \\mention{multiple}."))
            evs.append(ev("Q", Q_EXPANDED))
        if lex in ("lex_lot", "lex_plenty") and status == "licensed":
            conds.append(cond("construction",
                              "Common-noun control row: the supplement retains the article "
                              "\\mention{a} in \\mention{a lot} as part of the frame, and the "
                              "common-noun partitives follow \\textit{CGEL}. The lexeme record "
                              "carries the bare form only."
                              if lex == "lex_lot" else
                              "Common-noun control row: the cell records a quantificational "
                              "common noun, and the common-noun partitives follow \\textit{CGEL}."))
            if lex == "lex_lot":
                evs.append(ev("Q", Q_LOT_A))
            evs.append(ev("Q", Q_GR))
        if status == "licensed":
            conds.append(cond("construction",
                              "The supplement separates the NP dependent from the surrounding "
                              "construction; the claim covers this dependent type in this "
                              "surrounding construction only, and the supplement establishes no "
                              "ordering among the constructions."))
            evs.append(ev("Q", Q_SEP))
            evs.append(ev("Q", Q_ORDERING))
        participation.append({
            "id": qid,
            "lexeme_id": lex,
            "form": QUERIES[qid]["form"],
            "construction_id": COL_CONSTRUCTION[col],
            "status": status,
            "conditions": conds,
            "evidence": evs,
        })

assert qid_num == 55, qid_num

# ------------------------------------------------------------ X055 - X110 ---
MQ = {}
MQ["gradable"] = ("Degree \\mention{very}, \\mention{so}, and \\mention{too} select gradable "
                  "heads: \\mention{very tall} and \\mention{very few}")
MQ["series"] = ("The associated series includes \\mention{so few}, \\mention{too few}, "
                "\\mention{how few}, and \\mention{as few as}. These degree patterns select "
                "\\mention{few}, \\mention{many}, \\mention{much}, and \\mention{little}, the "
                "four determinatives that inflect for grade")
MQ["series_internal"] = ("The internal AdvP permissions at issue are thus the degree series on "
                         "\\mention{few}, \\mention{many}, \\mention{much}, and \\mention{little} "
                         "across dependent and independent uses, and approximatives on externally "
                         "determined independent cardinals.")
MQ["grade"] = ("The strongest adjectival connection also concerns a restricted group: "
               "\\mention{few}, \\mention{many}, \\mention{much}, and \\mention{little}. They "
               "distinguish plain, comparative, and superlative forms")
MQ["internal_attach"] = ("The proposed analysis gives adverbs such as \\mention{very} and "
                         "\\mention{too} internal attachment in dependent and independent uses "
                         "alike. In \\mention{the very few people}, \\mention{very} modifies the "
                         "Nom headed by \\mention{few}; the resulting \\mention{very few} NP "
                         "functions as Mod in the larger NP. In \\mention{the very few who "
                         "objected}, \\mention{few} remains ordinary Head and \\mention{very} "
                         "remains internal. The degree relation is unchanged, and one internal "
                         "permission covers both constructions. The same analysis applies to "
                         "\\mention{the very many}.")
MQ["excl_nongrad"] = ("These degree modifiers also exclude non-gradable determinatives: "
                      "\\ungram{\\mention{very every}}, \\ungram{\\mention{very some}}, and "
                      "\\ungram{\\mention{very this}}.")
MQ["numerous_so"] = ("Degree modification exposes a contrast: \\mention{so many mistakes} is "
                     "possible, while \\ungram{\\mention{so numerous mistakes}} is excluded")
MQ["afew"] = ("With the complex determinative \\mention{a few}, modifier position distinguishes "
              "two kinds of attachment. \\textit{CGEL} explicitly contrasts internal "
              "\\mention{very} in \\mention{a very few mistakes} with peripheral \\mention{quite} "
              "in \\mention{quite a few mistakes}")
MQ["afew_rev"] = ("The reversed orders \\ungram{\\mention{very a few}} and "
                  "\\ungram{\\mention{a quite few}} are excluded in these constructions. Here "
                  "\\mention{a} belongs to the complex determinative; \\mention{very} occurs "
                  "within it and \\mention{quite} outside it.")
MQ["afew_frag"] = ("Complex \\mention{a few} and \\mention{a little} have construction-specific "
                   "conditions, including the position of internal degree modifiers in "
                   "\\mention{a very few}. Their initial \\mention{a} isn't an ordinary Det "
                   "selecting a plural \\mention{few} target.")
MQ["periph_def"] = "Peripheral modifiers attach outside an NP's internal dependents."
MQ["fig_every"] = ("Figure~\\ref{fig:every} places \\mention{almost} at the periphery of the NP "
                   "headed by \\mention{every}.")
MQ["periph_cgel"] = "\\textit{CGEL} already assigns them NP-level attachment"
MQ["almost_every"] = ("In \\mention{almost every experienced teacher}, \\mention{almost} belongs "
                      "with \\mention{every}, while \\mention{experienced} modifies "
                      "\\mention{teacher}. Figure~\\ref{fig:every} places \\mention{almost} at the "
                      "periphery of the NP headed by \\mention{every}. That smaller NP functions "
                      "as Det in the larger NP, whose ultimate head is \\mention{teacher}.")
MQ["almost_quantity"] = ("In \\mention{almost every student}, \\mention{almost} approximates the "
                         "quantity; it doesn't intensify a gradable property of \\mention{every}.")
MQ["analytic"] = ("Determinative modifier attachments are analytical commitments; interrogative "
                  "and relative forms follow \\textit{CGEL}'s inventory.")
MQ["approx_list"] = ("Approximative and focusing modifiers have a broader distribution. Compare "
                     "\\mention{almost every}, \\mention{nearly all}, \\mention{hardly any}, "
                     "\\mention{practically no}, \\mention{almost everyone}, and "
                     "\\mention{almost ten}.")
MQ["payne_any"] = ("\\textcite[40--42]{payne2010} defend keeping \\mention{few}, \\mention{any}, "
                   "and related forms in one lexical category across dependent and independent "
                   "uses. In \\mention{hardly any money} and independent \\mention{hardly any}, "
                   "\\mention{hardly} remains an adverb and \\mention{any} retains its category. "
                   "The D-noun analysis preserves that continuity.")
MQ["nonone"] = ("\\textit{CGEL} treats them as inflectional forms of one determinative: dependent "
                "\\mention{no students} contrasts with independent \\mention{none}, while both "
                "permit \\mention{almost}")
MQ["nonone_part"] = ("The partitive \\mention{none of the students} requires the independent form; "
                     "\\ungram{\\mention{no of the students}} is excluded.")
MQ["nonone_form"] = "Form selection remains necessary, just as with \\mention{my}/\\mention{mine}."
MQ["almost_ten"] = ("Plain determinative-headed NPs, such as \\mention{almost ten} in "
                    "\\mention{almost ten apples}, then join genitives such as \\mention{Kim's} "
                    "and \\mention{my}.")
MQ["cardinal_qual"] = ("The cardinal examples are subject to the category qualifications in "
                       "§§\\ref{sec:evidence} and~\\ref{sec:costs}.")
MQ["cardinal_uses"] = ("It doesn't independently decide whether \\mention{three} is determinative "
                       "or has a common-noun use: \\textcite{reynolds2026numerals} argues for both "
                       "uses of cardinals.")
MQ["thirty"] = ("Approximatives also need internal attachment where they follow an external "
                "determiner on an independent cardinal: \\mention{the almost thirty who came}.")
MQ["two_sites"] = ("The approximatives retain the two attachment sites motivated in "
                   "§\\ref{sec:payne}: peripheral NP attachment in \\mention{almost every} and "
                   "internal attachment in externally determined \\mention{the almost thirty who "
                   "came}. Both ordinary-Head accounts require this distinction.")
MQ["comp_compl"] = ("Comparative complements, as in \\mention{more than ten}, are licensed "
                    "separately from partitive \\mention{of}-phrases.")
MQ["grade_profile"] = ("Grade combines with degree-modifier selection and comparative "
                       "complementation, as in \\mention{more than ten}. The three properties "
                       "form a connected profile.")
MQ["the_degree"] = ("\\mention{The} also functions as a degree modifier. In \\mention{the bigger "
                    "the better}, it modifies comparative AdjPs, as other determinatives do in "
                    "\\mention{much bigger} or \\mention{no better}")
MQ["the_degree2"] = ("This supplies a connection outside ordinary Det function while preserving "
                     "its exclusion from independent argument use.")
MQ["outside_np"] = ("The degree determinatives \\mention{much} and \\mention{little}, and "
                    "\\mention{no}/\\mention{none}, likewise have uses outside NP structure")
MQ["attributive_test"] = ("Attributive uses are the crucial test, because \\textit{CGEL} restricts "
                          "NP modifiers there.")
MQ["deal_contrast"] = ("\\textit{CGEL} contrasts predicative \\mention{a great deal better} with "
                       "\\ungram{\\mention{some a great deal better proposals}}, against permitted "
                       "\\mention{some much better proposals}")
MQ["deal_caveat"] = ("The excluded example also juxtaposes \\mention{some} and \\mention{a}; it "
                     "doesn't isolate NP category as the cause.")
MQ["lot_better"] = ("\\textit{CGEL} permits \\mention{She's a lot better player than me}, "
                    "analysing the inner article as lost after the outer one")
MQ["nps_modify_adj"] = ("NPs already modify adjectives in \\mention{three years old}, \\mention{a "
                        "great deal smaller}, and \\mention{plenty big enough}. \\textit{CGEL} also "
                        "explicitly treats \\mention{lots better} and \\mention{heaps worse} as "
                        "containing quantificational NP modifiers")
MQ["quant_nouns_degree"] = ("Quantificational nouns occur in degree modifiers such as \\mention{a "
                            "great deal smaller} and \\mention{plenty big enough}")
MQ["enough_section"] = ("Section~\\ref{sec:enough} compares these with determinative degree "
                        "modifiers, including their attributive distribution.")
MQ["informal_attr"] = ("Informal attributive examples with nominal \\mention{heaps} and "
                       "\\mention{lots} further qualify a categorical exclusion.")
MQ["informal_note"] = ("These are informal attestations; any register restriction remains to be "
                       "established.")
MQ["informal_limits"] = ("They don't establish the same distribution as degree determinatives. The "
                         "lexical, constructional, and register conditions remain a descriptive "
                         "question for all four accounts.")
MQ["dp_projection"] = ("If degree determinatives systematically permit attributive uses excluded "
                       "for established nominal modifiers, that difference would favour DP "
                       "projection.")
MQ["heaps_att"] = ("\\mention{Some heaps better photo's}: "
                   "\\href{https://www.aulro.com/afvb/motor-cycling/61858-my-track-day-phillip-island-motogp-track-post798794.html}"
                   "{AULRO, moose, 19 August 2008, post 2}; original spelling retained.")
MQ["lots_att"] = ("\\mention{Some lots better ones}: "
                  "\\href{https://www.uberpeople.net/threads/let-s-play-would-you-have-taken-this-trip.395130/}"
                  "{Uber Drivers Forum}, verified in an indexed excerpt; author and date remain "
                  "unverified.")
MQ["enough_np_mod"] = ("When \\mention{enough} modifies \\mention{good} in \\mention{good enough}, "
                       "the three NP-projecting implementations analyse it as an NP modifier of an "
                       "adjective.")
MQ["enough_pos"] = ("\\mention{Enough} tests both position and external function. It precedes a "
                    "nominal in \\mention{enough money} and can follow one in \\mention{money "
                    "enough}; post-head \\mention{enough} can't itself be premodified, as shown by "
                    "\\ungram{\\mention{money almost enough}}")
MQ["enough_targets"] = ("\\mention{Enough} also modifies adjectives, adverbs, verbs, and some PPs: "
                        "\\mention{good enough}, \\mention{quickly enough}, \\mention{I hadn't "
                        "prepared enough}, and \\mention{enough in control}")
MQ["enough_adjunct"] = ("Temporal NPs such as \\mention{that day} and \\mention{Sunday} supply "
                        "adjuncts, as does degree \\mention{enough} in \\mention{I hadn't prepared "
                        "enough}")
MQ["enough_is"] = ("Generalizing expressions such as \\mention{Many are called, few are chosen} and "
                   "\\mention{Enough is enough} need no previously uttered common-noun phrase. "
                   "Interpretation can instead depend on the situation or a generic restriction.")
MQ["cgel_indep_list"] = ("\\textit{CGEL} discusses such uses for demonstratives and quantifiers "
                         "including \\mention{some}, \\mention{all}, \\mention{both}, "
                         "\\mention{many}, \\mention{few}, \\mention{several}, \\mention{each}, "
                         "\\mention{either}, \\mention{neither}, \\mention{much}, and "
                         "\\mention{enough}, while recording lexical restrictions and the separate "
                         "forms \\mention{no}/\\mention{none}")
MQ["cgel_indep_gen"] = ("The generalization concerns the availability of independent constructions "
                        "across a lexical category, not unrestricted acceptability in every "
                        "sentence frame.")
MQ["all_agree"] = ("With a group of people under discussion, \\mention{Some left}, \\mention{Many "
                   "came}, and \\mention{All agree} illustrate \\term{syntactic completeness}: an "
                   "argument expression can be complete without another overt head or determiner.")
MQ["predet_all"] = ("Material before a determiner falls outside the independent-use comparison. "
                    "\\textit{CGEL} treats \\mention{all}/\\mention{both} in \\mention{all/both the "
                    "books} as predeterminer modifiers")
MQ["hudson_aside"] = ("He sets aside \\mention{all}, cardinal numerals, and quantifiers restricted "
                      "to plural or non-count nouns")
MQ["this_much"] = ("Determinatives permit determinative premodifiers such as \\mention{this} in "
                   "\\mention{this much}")
MQ["this_much2"] = ("The modifier \\mention{this} in \\mention{this much} expresses degree; its "
                    "permission doesn't follow from demonstrative Det selection.")
MQ["a_lot_fewer"] = ("Comparative determinatives also take established NP modifiers: \\mention{a "
                     "lot} in \\mention{a lot fewer}, alongside \\textit{CGEL}'s \\mention{a lot "
                     "more than fifty}")
MQ["np_degree_internal"] = ("These modify the quantity expressed by the head. Under the proposed "
                            "analysis, they're internal NP modifiers within its nominal projection, "
                            "with permissions specific to the head and construction.")
MQ["degree_selection"] = ("Degree-modifier selection applies across the relevant dependent and "
                          "independent uses. It includes AdvPs such as \\mention{very}, "
                          "determinative-headed modifiers such as \\mention{this} in \\mention{this "
                          "much}, and established NPs such as \\mention{a lot} in \\mention{a lot "
                          "fewer}.")
MQ["both_attested"] = ("\\mention{Went there yesterday: we are trying to decide between two "
                       "different Honda models, so we wanted to test-drive both back to back.}")
MQ["both_domain"] = ("In the following web-review sentence, \\mention{two different Honda models} "
                     "supplies the domain for the independent object \\mention{both}")
MQ["both_prov"] = ("English Web Treebank, sentence \\nolinkurl{reviews-083459-0002}, verified in "
                   "the \\href{https://github.com/UniversalDependencies/UD_English-EWT/blob/master/en_ewt-ud-train.conllu}"
                   "{UD English EWT training data}. CGELBank supplies the syntactic annotation "
                   "\\citep{reynolds2023unified}. The original review webpage wasn't identified.")
MQ["those"] = ("Determinative examples include \\mention{few who come ever leave}, \\mention{those "
               "who came}, \\mention{that which remains}, and \\mention{something that you need to "
               "know}.")
MQ["rel_cgel"] = ("\\textit{CGEL} describes relative postmodification with demonstratives and "
                  "compounds")
MQ["rel_integrated"] = ("Common nouns freely take integrated relatives, as in \\mention{people who "
                        "came}; personal pronouns permit a restricted range, including \\mention{we "
                        "who have read the report}")
MQ["rel_ordinary"] = ("The relative clauses in §\\ref{sec:independent} are ordinary postmodifiers, "
                      "distinct from the specialized restrictor.")
MQ["dem_number"] = ("Demonstratives likewise distinguish \\mention{this}/\\mention{these} and "
                    "\\mention{that}/\\mention{those}")
MQ["restrictor"] = ("The adjective realizes a specialized \\term{restrictor} function, restricted "
                    "to post-head position and non-recursive.")
MQ["compound_perm"] = ("The compound construction independently excludes external determination and "
                       "supplies the internal post-head restrictor permission, with the same "
                       "position and non-recursion conditions as the fusion account. It doesn't "
                       "license a corresponding pre-head adjective.")
MQ["hardly_anyone"] = ("\\textcite[581--583]{Payne2007} assign \\mention{hardly} to DP structure and "
                       "\\mention{present} to nominal structure. The compound \\mention{anyone} takes "
                       "the premodifiers of its determinative base \\mention{any}: compare "
                       "\\mention{hardly any writer present}.")
MQ["ordinary_head_tree"] = ("In the ordinary-Head tree, \\mention{anyone} inherits nominal projection "
                            "from Noun and its premodifier permissions from its determinative base. "
                            "Peripheral \\mention{hardly} follows the approximative pattern and its NP "
                            "parallels in §\\ref{sec:payne}.")
MQ["grouping_diff"] = ("Their constituent groupings differ: ordinary Head groups \\mention{anyone "
                       "present} in the inner NP, whereas fusion groups \\mention{hardly anyone} in DP.")
MQ["compounds_rel"] = ("Compounds also permit \\mention{anyone who asks} and \\mention{everything "
                       "that matters}.")
MQ["compounds_cgel_post"] = ("\\textit{CGEL} explicitly gives compounds the common noun's range of "
                             "ordinary postmodifiers while preserving this ordering condition")
MQ["order_rel"] = ("When both occur, the relative follows it: \\mention{something useful that I "
                   "found}.")
MQ["order_frag"] = ("The compounds permit at most one specialized post-head restrictor followed by "
                    "ordinary postmodifiers: \\mention{useful} precedes \\mention{that I found} in "
                    "\\mention{something useful that I found}. They exclude external determination "
                    "and a corresponding pre-head adjective.")
MQ["something_posthead"] = ("Compound determinatives also take post-head adjectives, as in \\mention{I "
                            "need something reliable and good looking}.")
MQ["someone_division"] = ("The same division applies to \\mention{someone} and \\mention{everybody}: "
                          "the compound construction licenses the post-head restrictor, while the "
                          "determinative base supplies its premodifier permissions.")
MQ["lot_delegates"] = ("In \\mention{a lot of the delegates} and \\mention{many of the delegates}, "
                       "both heads quantify over a partitive \\term{domain}: the whole from which a "
                       "quantity is drawn, here the delegates. But \\mention{lot} also permits "
                       "\\mention{a lot of delegates}, whereas \\ungram{\\mention{many of delegates}} "
                       "is excluded")
MQ["agreement"] = ("Compare the constructed \\mention{A lot of the people were waiting} and "
                   "\\mention{Some of the people were waiting}, with plural agreement, against "
                   "\\mention{A lot of the work was finished} and \\mention{Some of the work was "
                   "finished}, with singular agreement. The whole subject NP's number depends on the "
                   "complement of \\mention{of}. \\textit{CGEL} calls quantificational \\mention{lot} "
                   "\\term{number-transparent}")
MQ["number_transp"] = ("Number transparency specifically connects quantificational \\mention{lot} "
                       "with number-neutral \\mention{some}.")
MQ["plenty_lot_restr"] = ("\\textit{CGEL} categorizes quantificational \\mention{plenty} as a common "
                          "noun whose use resists determination and modification; \\mention{lot} "
                          "requires \\mention{a} and permits only limited modification")
MQ["approach_profile"] = ("Established common nouns thus approach the determinative profile as "
                          "determinatives approach theirs.")
MQ["some_partitive"] = ("In \\mention{some of the wine}, \\mention{some} specifies a quantity drawn "
                        "from an identifiable amount of wine. The NP \\mention{the wine} denotes the "
                        "partitive domain and is complement of \\mention{of}. A pronoun-headed NP or "
                        "independent genitive NP can express the domain too: \\mention{many of them}, "
                        "referring to previously mentioned people, or \\mention{some of Kim's}, "
                        "referring to Kim's apples.")
MQ["partitive_head"] = ("In the partitive, \\mention{wine} is embedded inside the \\mention{of}-phrase, "
                        "so it can't be the ultimate lexical head of the whole NP. The Head relations "
                        "in both analyses lead instead to \\mention{some}.")
MQ["partitive_fig"] = ("Figure~\\ref{fig:partitive} gives the D-noun analysis, with the "
                       "\\mention{of}-phrase functioning as complement within Nom, as in "
                       "\\textit{CGEL}'s partitive tree")
MQ["dep_excl"] = ("In Det or internal Mod function before a target, ordinary \\mention{some} and "
                  "\\mention{few} exclude external determination, partitive complements, and "
                  "relative postmodifiers within their own phrase.")
MQ["predicative"] = ("Predicative \\mention{Its advantages are several} and \\mention{Their enemies "
                     "were many} provide further overlap, though the latter is uncommon and formal")
MQ["fragment_scope"] = ("Predication, interrogative clause structure, and modification outside NP "
                        "structure lie beyond its scope.")
MQ["fragment_covers"] = ("The fragment covers determination, internal nominal modification, ordinary "
                         "subject, object, and complement-of-preposition uses, partitives, and the "
                         "compound comparisons in §\\ref{sec:evidence}.")
MQ["specifying_be"] = ("\\textit{CGEL} excludes specifying \\mention{be} clauses from its "
                       "noun--adjective diagnostic because phrases from other categories occur in "
                       "them too")
MQ["pred_np_adjp"] = ("in \\mention{Jones became president/ill}, NP and AdjP share predicative "
                      "complement function. External functions alone therefore don't establish "
                      "nounhood.")
MQ["mine_pred"] = ("Predicative \\mention{mine}, as in \\mention{it's mine}, can instead mean "
                   "\\enquote*{belongs to me}: it expresses the relation directly, without an "
                   "understood nominal head")
MQ["mine_anaph"] = ("Anaphoric \\mention{mine}, understood as \\enquote*{my car}, combines the "
                    "possessive relation with an understood nominal description and receives a fused "
                    "analysis.")
MQ["mine_either"] = "A suitable context may permit either reading."
MQ["mine_ordinary"] = ("The proposed analysis gives \\mention{mine} ordinary Head in both anaphoric "
                       "and predicative uses.")
MQ["mine_agreement"] = ("The genitive's person identifies the possessor; the independent NP's "
                        "agreement reflects the possessed entity or entities.")
MQ["my_paradigm"] = ("Dependent \\mention{my} and independent \\mention{mine} belong to one pronoun "
                     "paradigm.")
MQ["article_targets"] = ("\\mention{The} permits singular, plural, and non-count targets; \\mention{a} "
                         "selects a singular count target and contributes individuation.")
MQ["a_row"] = "\\mention{a} & yes & -- & -- & -- & Singular count \\\\"
MQ["perm_header"] = "Form & Det & Mod & Subj & Obj / CompP & Target before another nominal \\\\"
MQ["article_system"] = ("The articles participate in the determinative system of definiteness, "
                        "quantity, and count restrictions.")
MQ["article_noindep"] = ("The articles lack an independent argument form; their positive evidence is "
                         "integration into determinative, and their nounhood depends on the "
                         "category-level argument.")
MQ["many_numerous"] = ("\\mention{Numerous people} and \\mention{many people} both quantify, but their "
                       "syntax differs.")
MQ["semantic_control"] = ("Quantity meaning and prenominal position provide a semantic control for the "
                          "nominal comparison. Independent use tests whether their further "
                          "distributions sustain the distinction.")
MQ["quant_adj_head"] = "\\subsection{Quantificational adjectives and nominal independence}"
MQ["indep_quant_extend"] = ("Independent uses extend to \\mention{numerous}, \\mention{multiple}, and "
                            "\\mention{countless}.")
MQ["circular"] = ("These selected occurrences establish overlap, without establishing equal "
                  "acceptability or frequency. Assigning every independent quantity word to "
                  "determinative would make independent use a circular category diagnostic.")
MQ["rich_det"] = ("Independent \\mention{some} can form a one-word NP, whereas an NP with "
                  "\\mention{rich} as fused head requires the definite article \\mention{the} on the "
                  "generic human reading")
MQ["rich_local"] = ("That's a local contrast: argument NPs headed by singular count common nouns also "
                    "need determination.")
MQ["rich_plural"] = ("Generic human \\mention{the rich}, by contrast, is a plural NP whose adjective "
                     "lacks number inflection and still takes adverb modifiers: \\mention{the very "
                     "rich}")
MQ["rich_agree"] = ("Plural agreement likewise occurs with adjective-containing \\mention{the rich}, "
                    "whose adjective lacks number inflection")
MQ["rich_fused"] = ("Independent uses containing fused-head adjective phrases (AdjPs) prevent a simple "
                    "inference from these positions to nounhood. \\mention{The rich} and \\mention{the "
                    "poor} can fill nominal argument positions.")
MQ["second"] = ("Adjective fusion permits indefinite ordinal \\mention{a second} "
                "\\citep[416]{huddleston2002}, giving the constructed comparison \\mention{There "
                "was a second}.")
MQ["exist_nodecide"] = "Existential occurrence doesn't decide the structural analysis either."
MQ["exist_several"] = ("Existentials add a construction to this comparison. With possible solutions "
                       "under discussion, the constructed \\mention{There are several} places the "
                       "independent quantifier in displaced-subject position; dummy \\mention{there} "
                       "is the subject")
MQ["completeness_mods"] = ("\\textit{CGEL} also records modifiers of completeness, including "
                           "\\mention{marginally enough} and \\mention{absolutely all}, with different "
                           "selectional ranges")
MQ["completeness_no_ext"] = ("Those combinations don't extend the "
                             "\\mention{very}/\\mention{so}/\\mention{too}/\\mention{how} series beyond "
                             "the four degree determinatives.")
MQ["one_lexemes"] = ("\\textcite[797--798]{payne2013anaphoric} distinguish three lexemes spelled "
                     "\\mention{one}: determinative, anaphoric common noun, and generic personal "
                     "pronoun. These remain distinct under the D-noun categorization, but all belong "
                     "within primary Noun.")
MQ["one_anaphoric"] = ("\\textcite[797--798]{payne2013anaphoric} analyse anaphoric \\mention{one} as a "
                       "common count noun, distinct from determinative \\mention{one} and personal "
                       "pronoun \\mention{one}.")
MQ["one_grouping"] = ("Both D-noun implementations share this grouping of cardinals and the three "
                      "\\mention{one} lexemes.")
MQ["cgel_lots_heaps"] = ("\\textit{CGEL} also explicitly treats \\mention{lots better} and "
                         "\\mention{heaps worse} as containing quantificational NP modifiers")

E = ev


def claim(qid, lex, cons, status, conds, evs):
    assert QUERIES[qid]["lexeme_id"] == lex, qid
    assert QUERIES[qid]["construction_id"] == cons, qid
    participation.append({
        "id": qid,
        "lexeme_id": lex,
        "form": QUERIES[qid]["form"],
        "construction_id": cons,
        "status": status,
        "conditions": conds,
        "evidence": evs,
    })


SCOPE_ANALYTIC = cond(
    "construction",
    "Attribution: the manuscript marks determinative modifier attachments as the "
    "author's analytical commitments, not \\textit{CGEL} assignments.")

claim("X055", "lex_few", "internal_mod_admission", "licensed", [
    cond("own_phrase",
         "The modifier is a degree adverb of the \\mention{very}/\\mention{so}/"
         "\\mention{too}/\\mention{how}/\\mention{as ... as} series, which selects gradable "
         "heads; \\mention{few} is one of the four determinatives that inflect for grade."),
    cond("own_phrase",
         "Attachment: the degree adverb attaches inside \\mention{few}'s own nominal "
         "projection (it modifies the Nom headed by \\mention{few}), in the dependent use "
         "\\mention{the very few people} and in the independent use \\mention{the very few "
         "who objected} alike; one internal permission covers both constructions."),
    cond("construction",
         "Uses covered: dependent uses before a target nominal and independent uses, "
         "including externally determined ones."),
    SCOPE_ANALYTIC,
    cond("construction",
         "The restriction concerns this degree series; \\textit{CGEL}'s modifiers of "
         "completeness have different selectional ranges and don't extend the series beyond "
         "the four degree determinatives."),
], [E("M", MQ["gradable"]), E("M", MQ["series"]), E("M", MQ["internal_attach"]),
    E("M", MQ["grade"]), E("M", MQ["series_internal"]), E("M", MQ["completeness_no_ext"]),
    E("M", MQ["analytic"])])

claim("X056", "lex_many", "internal_mod_admission", "licensed", [
    cond("own_phrase",
         "The modifier is a degree adverb of the \\mention{very}/\\mention{so}/"
         "\\mention{too}/\\mention{how} series; \\mention{many} is one of the four "
         "grade-inflecting determinatives the series selects."),
    cond("own_phrase",
         "Attachment: internal to \\mention{many}'s own nominal projection; the analysis "
         "given for \\mention{the very few people} and \\mention{the very few who objected} "
         "applies to \\mention{the very many} as well."),
    cond("construction",
         "Restriction on the series: it selects \\mention{few}, \\mention{many}, "
         "\\mention{much}, and \\mention{little} and excludes non-gradable determinatives; "
         "modifiers of completeness have different selectional ranges."),
    SCOPE_ANALYTIC,
], [E("M", MQ["numerous_so"]), E("M", MQ["series"]), E("M", MQ["internal_attach"]),
    E("M", MQ["excl_nongrad"]), E("M", MQ["series_internal"]), E("M", MQ["analytic"])])

claim("X057", "lex_much", "internal_mod_admission", "licensed", [
    cond("own_phrase",
         "The manuscript states the permission for \\mention{much} as one of the four "
         "determinatives that inflect for grade (\\mention{few}, \\mention{many}, "
         "\\mention{much}, \\mention{little}), not through an individual example of "
         "\\mention{much} with a degree adverb of this series."),
    cond("own_phrase",
         "Attachment: the internal AdvP permissions at issue are the degree series on "
         "\\mention{few}, \\mention{many}, \\mention{much}, and \\mention{little} across "
         "dependent and independent uses."),
    SCOPE_ANALYTIC,
], [E("M", MQ["series"]), E("M", MQ["grade"]), E("M", MQ["series_internal"]),
    E("M", MQ["analytic"])])

claim("X058", "lex_little", "internal_mod_admission", "licensed", [
    cond("own_phrase",
         "The manuscript states the permission for \\mention{little} as one of the four "
         "determinatives that inflect for grade, not through an individual example of "
         "\\mention{little} with a degree adverb of this series."),
    cond("own_phrase",
         "Attachment: the internal AdvP permissions at issue are the degree series on "
         "\\mention{few}, \\mention{many}, \\mention{much}, and \\mention{little} across "
         "dependent and independent uses."),
    SCOPE_ANALYTIC,
], [E("M", MQ["series"]), E("M", MQ["grade"]), E("M", MQ["series_internal"]),
    E("M", MQ["analytic"])])

claim("X059", "lex_some", "internal_mod_admission", "excluded", [
    cond("own_phrase",
         "Property appealed to: degree \\mention{very}, \\mention{so}, and \\mention{too} "
         "select gradable heads, and the manuscript lists \\mention{some} among the "
         "non-gradable determinatives these modifiers exclude; the sequence "
         "\\mention{very some} is marked ungrammatical."),
], [E("M", MQ["excl_nongrad"]), E("M", MQ["gradable"]), E("M", MQ["series"])])

claim("X060", "lex_every", "internal_mod_admission", "excluded", [
    cond("own_phrase",
         "Property appealed to: degree \\mention{very}, \\mention{so}, and \\mention{too} "
         "select gradable heads, and \\mention{every} is listed among the non-gradable "
         "determinatives they exclude; the sequence \\mention{very every} is marked "
         "ungrammatical. This is distinct from the approximative \\mention{almost every}, "
         "where \\mention{almost} approximates the quantity rather than intensifying a "
         "gradable property."),
], [E("M", MQ["excl_nongrad"]), E("M", MQ["gradable"]), E("M", MQ["almost_quantity"])])

claim("X061", "lex_numerous", "internal_mod_admission", "excluded", [
    cond("construction",
         "Use of the contrast: the manuscript sets the excluded \\mention{so numerous "
         "mistakes} against the possible \\mention{so many mistakes} to show that "
         "\\mention{numerous} and \\mention{many}, though both quantifying and both "
         "prenominal, differ in syntax; degree modification is the exposed contrast."),
], [E("M", MQ["numerous_so"]), E("M", MQ["many_numerous"]), E("M", MQ["semantic_control"])])

claim("X062", "lex_few", "internal_mod_admission", "licensed", [
    cond("construction",
         "Stated context: the complex determinative \\mention{a few}; the article "
         "\\mention{a} belongs to the complex determinative and is part of the frame, not of "
         "the lexeme's form."),
    cond("own_phrase",
         "Attachment: \\mention{very} is internal to the complex determinative in \\mention{a "
         "very few mistakes}; \\textit{CGEL} explicitly contrasts this internal attachment "
         "with peripheral \\mention{quite}."),
    cond("own_phrase",
         "Ordering condition: the reversed sequence \\mention{very a few} is marked "
         "ungrammatical in this construction."),
    cond("construction",
         "The fragment records \\mention{a few} as a complex determinative with "
         "construction-specific conditions, including the position of internal degree "
         "modifiers, and leaves its internal analysis beyond the position contrast "
         "unspecified; whether the lexeme record for these cases should be \\mention{few} or "
         "the complex unit is not settled by the documents."),
], [E("M", MQ["afew"]), E("M", MQ["afew_rev"]), E("M", MQ["afew_frag"])])

claim("X063", "lex_few", "peripheral_mod_admission", "licensed", [
    cond("construction",
         "Stated context: the complex determinative \\mention{a few}; the article "
         "\\mention{a} belongs to the complex determinative and is part of the frame."),
    cond("outer_np",
         "Attachment: \\mention{quite} is peripheral, occurring outside the complex "
         "determinative (outside its article and internal dependents), in \\mention{quite a "
         "few mistakes}."),
    cond("own_phrase",
         "Ordering condition: the sequence \\mention{a quite few} is marked ungrammatical in "
         "this construction."),
], [E("M", MQ["afew"]), E("M", MQ["afew_rev"]), E("M", MQ["periph_def"])])

claim("X064", "lex_every", "peripheral_mod_admission", "licensed", [
    cond("outer_np",
         "Attachment: \\mention{almost} is placed at the periphery of the smaller NP headed "
         "by \\mention{every}; that \\mention{almost every} NP then functions as Det in the "
         "larger NP, whose ultimate head is \\mention{teacher}."),
    cond("own_phrase",
         "What \\mention{almost} applies to: it approximates the quantity and does not "
         "intensify a gradable property of \\mention{every}; it belongs with \\mention{every} "
         "rather than with the following adjective and nominal."),
    cond("construction",
         "Attribution: \\textit{CGEL} already assigns peripheral modifiers NP-level "
         "attachment, but the specific determinative modifier attachments, including this "
         "one, are the manuscript's analytical commitments rather than \\textit{CGEL} "
         "assignments."),
], [E("M", MQ["almost_every"]), E("M", MQ["almost_quantity"]), E("M", MQ["periph_cgel"]),
    E("M", MQ["periph_def"]), E("M", MQ["analytic"]), E("M", MQ["approx_list"])])

claim("X065", "lex_any", "peripheral_mod_admission", "licensed", [
    cond("outer_np",
         "Attachment: peripheral \\mention{hardly} follows the approximative pattern and its "
         "NP parallels, attaching outside the NP's internal dependents."),
    cond("construction",
         "Both uses covered: the dependent \\mention{hardly any money} and the independent "
         "\\mention{hardly any} keep \\mention{hardly} an adverb and \\mention{any} in its "
         "category, and the manuscript preserves that continuity across the two uses."),
    SCOPE_ANALYTIC,
], [E("M", MQ["payne_any"]), E("M", MQ["ordinary_head_tree"]), E("M", MQ["periph_def"]),
    E("M", MQ["approx_list"]), E("M", MQ["analytic"])])

claim("X066", "lex_no", "peripheral_mod_admission", "licensed", [
    cond("outer_np",
         "Attachment: approximative and focusing modifiers attach at the periphery, outside "
         "an NP's internal dependents; \\textit{CGEL} assigns them NP-level attachment."),
    cond("construction",
         "Modifiers actually exemplified for the dependent form \\mention{no}: "
         "\\mention{practically no} in the list of approximative and focusing modifiers, and "
         "\\mention{almost}, which \\textit{CGEL} is reported to permit with both "
         "\\mention{no} and \\mention{none}. The sequence \\mention{almost no} itself is not "
         "written out in the documents."),
    SCOPE_ANALYTIC,
], [E("M", MQ["approx_list"]), E("M", MQ["nonone"]), E("M", MQ["periph_cgel"]),
    E("M", MQ["periph_def"]), E("M", MQ["analytic"])])

claim("X067", "lex_no", "peripheral_mod_admission", "licensed", [
    cond("own_phrase",
         "Form selection: \\mention{no} and \\mention{none} are treated as inflectional forms "
         "of one determinative; \\mention{none} is the independent form and \\mention{no} the "
         "dependent one, and both are reported to permit \\mention{almost}."),
    cond("own_phrase",
         "Separate condition on the partitive: \\mention{none of the students} requires the "
         "independent form, while \\mention{no of the students} is excluded; this is a "
         "form-selection condition, not a modifier condition."),
    cond("own_phrase",
         "Basis of the peripheral classification: no statement about \\mention{none} assigns "
         "an attachment site, so peripheral attachment for \\mention{almost} with "
         "\\mention{none} follows the manuscript's general analysis of approximatives, which "
         "places them outside an NP's internal dependents (illustrated with \\mention{almost "
         "every}); the same analysis assigns approximatives internal attachment where they "
         "follow an external determiner on an independent cardinal, as in \\mention{the almost "
         "thirty who came}."),
    cond("construction",
         "Function split not represented: the record's construction vocabulary does not "
         "separate the dependent and independent functions of the two forms beyond what is "
         "stated here."),
], [E("M", MQ["nonone"]), E("M", MQ["nonone_part"]), E("M", MQ["nonone_form"]),
    E("M", MQ["periph_def"]), E("M", MQ["fig_every"]), E("M", MQ["thirty"])])

claim("X068", "lex_ten", "peripheral_mod_admission", "licensed", [
    cond("outer_np",
         "Attachment: peripheral NP attachment, as in \\mention{almost every}; \\mention{almost "
         "ten} is a plain determinative-headed NP that joins genitives such as \\mention{Kim's} "
         "and \\mention{my} in Det function in \\mention{almost ten apples}."),
    cond("construction",
         "Category qualification on cardinals: the cardinal examples are subject to the "
         "manuscript's category qualifications, and the cited analysis argues for both "
         "determinative and common-noun uses of cardinals, so the example doesn't by itself fix "
         "the cardinal's subcategory."),
    SCOPE_ANALYTIC,
], [E("M", MQ["approx_list"]), E("M", MQ["almost_ten"]), E("M", MQ["two_sites"]),
    E("M", MQ["cardinal_qual"]), E("M", MQ["cardinal_uses"]), E("M", MQ["analytic"])])

claim("X069", "lex_thirty", "internal_mod_admission", "licensed", [
    cond("own_phrase",
         "Attachment required here: internal attachment inside the cardinal's own projection, "
         "because the approximative follows an external determiner on an independent cardinal "
         "in \\mention{the almost thirty who came}."),
    cond("construction",
         "Difference from \\mention{almost every}: the approximatives retain two attachment "
         "sites, peripheral NP attachment in \\mention{almost every} and internal attachment in "
         "the externally determined \\mention{the almost thirty who came}; both ordinary-Head "
         "accounts require the distinction."),
    SCOPE_ANALYTIC,
], [E("M", MQ["thirty"]), E("M", MQ["two_sites"]), E("M", MQ["analytic"])])

claim("X070", "lex_many", "comparative_complement", "licensed", [
    cond("own_phrase",
         "The comparative \\mention{than}-phrase is licensed separately from partitive "
         "\\mention{of}-phrases; they are distinct dependent types in the fragment."),
    cond("construction",
         "Lexemes the property is stated for: grade, degree-modifier selection and comparative "
         "complementation form one connected profile in the four grade-inflecting quantifiers "
         "\\mention{few}, \\mention{many}, \\mention{much}, and \\mention{little}; "
         "\\mention{more} is the comparative form in the \\mention{many}/\\mention{more}/"
         "\\mention{most} paradigm."),
], [E("M", MQ["comp_compl"]), E("M", MQ["grade_profile"]), E("M", MQ["grade"])])

claim("X071", "lex_the", "degree_modifier_adj", "licensed", [
    cond("construction",
         "Construction it is restricted to: \\mention{the bigger the better}, where "
         "\\mention{the} modifies comparative AdjPs, as other determinatives do in "
         "\\mention{much bigger} or \\mention{no better}."),
    cond("own_phrase",
         "Bearing on argument use: this degree use supplies a connection outside ordinary Det "
         "function while preserving \\mention{the}'s exclusion from independent argument use; "
         "the manuscript does not treat it as evidence for an independent argument use."),
], [E("M", MQ["the_degree"]), E("M", MQ["the_degree2"]), E("M", MQ["article_noindep"])])

claim("X072", "lex_no", "degree_modifier_adj", "licensed", [
    cond("construction",
         "Stated as a degree use outside NP structure: \\mention{no better} is cited alongside "
         "\\mention{much bigger} as a determinative modifying a comparative AdjP, and the "
         "degree determinatives \\mention{much} and \\mention{little}, and \\mention{no}/"
         "\\mention{none}, are said to have uses outside NP structure."),
    cond("construction",
         "Degree uses enter the wider comparison rather than the fragment: the fragment places "
         "modification outside NP structure beyond its scope."),
], [E("M", MQ["the_degree"]), E("M", MQ["outside_np"]), E("M", MQ["fragment_scope"])])

claim("X073", "lex_much", "degree_modifier_adj", "licensed", [
    cond("construction",
         "Attributive position specifically: \\mention{some much better proposals} is the "
         "permitted member of \\textit{CGEL}'s contrast, against the excluded \\mention{some a "
         "great deal better proposals}."),
    cond("construction",
         "Why the position matters: attributive uses are the crucial test in the manuscript's "
         "comparison, because \\textit{CGEL} restricts NP modifiers there."),
], [E("M", MQ["deal_contrast"]), E("M", MQ["attributive_test"]), E("M", MQ["enough_np_mod"])])

claim("X074", "lex_deal", "degree_modifier_adj", "licensed", [
    cond("construction",
         "Stated frame: the retained \\mention{a great} belongs to the frame \\mention{a great "
         "deal smaller} / predicative \\mention{a great deal better}, not to the lexeme's form."),
    cond("own_phrase",
         "Category assigned to the modifier: a quantificational noun, i.e. an NP modifier of "
         "an adjective; the manuscript groups \\mention{a great deal smaller} with "
         "\\mention{three years old} and \\mention{plenty big enough} as NPs modifying "
         "adjectives."),
    cond("construction",
         "Position: outside attributive position, including the predicative \\mention{a great "
         "deal better} that \\textit{CGEL} contrasts with the excluded attributive sequence."),
], [E("M", MQ["quant_nouns_degree"]), E("M", MQ["nps_modify_adj"]), E("M", MQ["deal_contrast"])])

claim("X075", "lex_deal", "degree_modifier_adj", "excluded", [
    cond("construction",
         "\\textit{CGEL}'s judgment: \\mention{some a great deal better proposals} is marked "
         "ungrammatical, in contrast with predicative \\mention{a great deal better} and with "
         "permitted attributive \\mention{some much better proposals}."),
    cond("construction",
         "Manuscript's caveat: the excluded example also juxtaposes \\mention{some} and "
         "\\mention{a}, so it doesn't isolate NP category as the cause of the exclusion; "
         "\\textit{CGEL} permits \\mention{She's a lot better player than me}, analysing the "
         "inner article as lost after the outer one."),
    cond("construction",
         "Scope: the lexical, constructional, and register conditions on attributive degree "
         "modification remain a descriptive question for all four accounts."),
], [E("M", MQ["deal_contrast"]), E("M", MQ["deal_caveat"]), E("M", MQ["lot_better"]),
    E("M", MQ["informal_limits"])])

claim("X076", "lex_lot", "degree_modifier_adj", "licensed", [
    cond("construction",
         "Stated frame: the article belongs to the frame \\mention{She's a lot better player "
         "than me}, not to the lexeme's form."),
    cond("construction",
         "\\textit{CGEL}'s judgment: the attributive example is permitted, with the inner "
         "article analysed as lost after the outer one."),
    cond("construction",
         "Scope: the manuscript treats attributive uses as the crucial test and leaves the "
         "lexical, constructional, and register conditions a descriptive question."),
], [E("M", MQ["lot_better"]), E("M", MQ["attributive_test"]), E("M", MQ["informal_limits"])])

claim("X077", "lex_lots", "degree_modifier_adj", "licensed", [
    cond("own_phrase",
         "Category assigned to the modifier: \\textit{CGEL} is reported to treat \\mention{lots "
         "better} and \\mention{heaps worse} as containing quantificational NP modifiers."),
    cond("construction",
         "Position: outside attributive position; this cell records that use only."),
    cond("own_phrase",
         "Lexeme identity: the documents don't state whether \\mention{lots} is a form of the "
         "quantificational lexeme \\mention{lot} or a separate lexeme, so no such relation is "
         "assumed here."),
], [E("M", MQ["cgel_lots_heaps"]), E("M", MQ["nps_modify_adj"])])

claim("X078", "lex_lots", "degree_modifier_adj", "licensed", [
    cond("construction",
         "Evidential basis: an informal attestation, \\mention{Some lots better ones}, from the "
         "Uber Drivers Forum, verified in an indexed excerpt; author and date remain "
         "unverified."),
    cond("construction",
         "Character and scope: these are informal attestations, and any register restriction "
         "remains to be established; they don't establish the same distribution as degree "
         "determinatives, and the lexical, constructional, and register conditions remain a "
         "descriptive question for all four accounts."),
    cond("construction",
         "Role in the argument: informal attributive examples with nominal \\mention{heaps} and "
         "\\mention{lots} further qualify a categorical exclusion of NP modifiers in "
         "attributive position."),
    cond("own_phrase",
         "Lexeme identity: no relation between \\mention{lots} and quantificational "
         "\\mention{lot} is stated in the documents."),
], [E("M", MQ["informal_attr"]), E("M", MQ["lots_att"]), E("M", MQ["informal_note"]),
    E("M", MQ["informal_limits"])])

claim("X079", "lex_heaps", "degree_modifier_adj", "licensed", [
    cond("own_phrase",
         "Category assigned to the modifier: \\textit{CGEL} is reported to treat \\mention{lots "
         "better} and \\mention{heaps worse} as containing quantificational NP modifiers."),
    cond("construction", "Position: outside attributive position."),
    cond("own_phrase",
         "Lexeme identity: the documents don't state whether \\mention{heaps} is a form of a "
         "quantificational lexeme \\mention{heap} or a separate lexeme."),
], [E("M", MQ["cgel_lots_heaps"]), E("M", MQ["nps_modify_adj"])])

claim("X080", "lex_heaps", "degree_modifier_adj", "licensed", [
    cond("construction",
         "Evidential basis: an informal attestation, \\mention{Some heaps better photo's}, from "
         "AULRO, poster moose, 19 August 2008, post 2, with the original spelling retained."),
    cond("construction",
         "Character and scope: these are informal attestations; any register restriction "
         "remains to be established, they don't establish the same distribution as degree "
         "determinatives, and the lexical, constructional, and register conditions remain a "
         "descriptive question for all four accounts."),
    cond("construction",
         "Role in the argument: the example further qualifies a categorical exclusion of "
         "nominal modifiers in attributive position; if degree determinatives systematically "
         "permitted attributive uses excluded for established nominal modifiers, that "
         "difference would favour DP projection."),
    cond("own_phrase",
         "Lexeme identity: no relation between \\mention{heaps} and a quantificational lexeme "
         "\\mention{heap} is stated."),
], [E("M", MQ["informal_attr"]), E("M", MQ["heaps_att"]), E("M", MQ["informal_note"]),
    E("M", MQ["informal_limits"]), E("M", MQ["dp_projection"])])

claim("X081", "lex_plenty", "degree_modifier_adj", "licensed", [
    cond("own_phrase",
         "Category assigned to the modifier: a quantificational noun; \\mention{plenty big "
         "enough} is grouped with \\mention{a great deal smaller} as a degree modifier headed "
         "by a quantificational noun, and with \\mention{three years old} as an NP modifying "
         "an adjective."),
    cond("construction",
         "Sections in which the manuscript uses it: the connection from quantificational "
         "common nouns (§2.2, sec:quant-nouns), and the comparison of degree uses outside noun "
         "phrases (sec:enough)."),
], [E("M", MQ["quant_nouns_degree"]), E("M", MQ["nps_modify_adj"]), E("M", MQ["enough_section"])])

claim("X082", "lex_enough", "degree_modifier_adj", "licensed", [
    cond("construction",
         "Position: \\mention{enough} follows the adjective in \\mention{good enough}; the "
         "three NP-projecting implementations analyse it there as an NP modifier of an "
         "adjective."),
    cond("construction",
         "Restriction on modifying \\mention{enough} itself: the documents state that "
         "post-head \\mention{enough} can't itself be premodified, and tie that statement to "
         "the position after a nominal, as shown by the excluded \\mention{money almost "
         "enough}; no corresponding statement is made about \\mention{enough} after an "
         "adjective."),
], [E("M", MQ["enough_np_mod"]), E("M", MQ["enough_targets"]), E("M", MQ["enough_pos"])])

claim("X083", "lex_enough", "degree_modifier_nonadj", "licensed", [
    cond("construction",
         "Target category: an adverb, as in \\mention{quickly enough}; \\mention{enough} also "
         "modifies adjectives, verbs, and some PPs."),
    cond("construction",
         "Position: \\mention{enough} follows the modified adverb in the cited example."),
], [E("M", MQ["enough_targets"])])

claim("X084", "lex_enough", "degree_modifier_nonadj", "licensed", [
    cond("construction",
         "Target category: a verb, as in \\mention{I hadn't prepared enough}."),
    cond("construction",
         "The manuscript also describes this occurrence as a clause adjunct, alongside "
         "temporal NP adjuncts such as \\mention{that day} and \\mention{Sunday}."),
], [E("M", MQ["enough_targets"]), E("M", MQ["enough_adjunct"])])

claim("X085", "lex_this", "degree_modifier_nonadj", "licensed", [
    cond("construction",
         "Target category: a determinative-headed target, \\mention{much} in \\mention{this "
         "much}; \\textit{CGEL} is cited for determinatives permitting determinative "
         "premodifiers."),
    cond("own_phrase",
         "Attachment: under the proposed analysis these degree modifiers are internal NP "
         "modifiers within the head's nominal projection, with permissions specific to the "
         "head and construction."),
    cond("own_phrase",
         "The permission does not follow from demonstrative Det selection: the modifier "
         "\\mention{this} in \\mention{this much} expresses degree, and its permission is "
         "stated separately."),
    SCOPE_ANALYTIC,
], [E("M", MQ["this_much"]), E("M", MQ["np_degree_internal"]), E("M", MQ["this_much2"]),
    E("M", MQ["degree_selection"]), E("M", MQ["analytic"])])

claim("X086", "lex_lot", "degree_modifier_nonadj", "licensed", [
    cond("construction",
         "Stated frame: the article belongs to the frame \\mention{a lot fewer} and "
         "\\textit{CGEL}'s \\mention{a lot more than fifty}, not to the lexeme's form."),
    cond("construction",
         "Target category: a comparative determinative-headed target; comparative "
         "determinatives take established NP modifiers."),
    cond("own_phrase",
         "What the modifier modifies, and attachment: these modifiers modify the quantity "
         "expressed by the head, and under the proposed analysis they are internal NP "
         "modifiers within its nominal projection, with permissions specific to the head and "
         "construction."),
    SCOPE_ANALYTIC,
], [E("M", MQ["a_lot_fewer"]), E("M", MQ["np_degree_internal"]), E("M", MQ["degree_selection"]),
    E("M", MQ["analytic"])])

claim("X087", "lex_enough", "dependent_det", "licensed", [
    cond("target_nominal",
         "The documents state only that \\mention{enough} precedes a nominal in "
         "\\mention{enough money}; no count, number or other target-selection restriction is "
         "stated for \\mention{enough} in the fragment's permissions table or elsewhere in the "
         "two sources."),
    cond("construction",
         "Position kept distinct: \\mention{enough} can also follow a nominal in "
         "\\mention{money enough}, which is a separate position and is not covered by this "
         "record."),
], [E("M", MQ["enough_pos"]), E("M", MQ["enough_targets"]), E("M", MQ["perm_header"])])

claim("X088", "lex_enough", "internal_mod_admission", "excluded", [
    cond("construction",
         "Position to which the statement is tied: post-head \\mention{enough}, i.e. "
         "\\mention{enough} following a nominal as in \\mention{money enough}; the excluded "
         "sequence is \\mention{money almost enough}."),
    cond("construction",
         "The exclusion is stated for premodification of post-head \\mention{enough} only; no "
         "corresponding statement is made for pre-nominal \\mention{enough money} or for "
         "\\mention{enough} after an adjective."),
], [E("M", MQ["enough_pos"])])

claim("X089", "lex_enough", "independent_argument", "licensed", [
    cond("construction",
         "Interpretation without an antecedent nominal phrase: generalizing expressions such "
         "as \\mention{Enough is enough} need no previously uttered common-noun phrase, and "
         "interpretation can depend instead on the situation or a generic restriction."),
    cond("construction",
         "Basis for independent use: \\textit{CGEL} discusses independent uses for a list of "
         "quantifiers including \\mention{enough}, while recording lexical restrictions; the "
         "generalization concerns the availability of independent constructions across a "
         "lexical category, not unrestricted acceptability in every sentence frame."),
], [E("M", MQ["enough_is"]), E("M", MQ["cgel_indep_list"]), E("M", MQ["cgel_indep_gen"])])

claim("X090", "lex_all", "independent_argument", "licensed", [
    cond("construction",
         "Basis: \\textit{CGEL} discusses independent uses for demonstratives and quantifiers "
         "including \\mention{all}, and the manuscript adds the constructed \\mention{All "
         "agree}, with a group of people under discussion, as an illustration of syntactic "
         "completeness."),
    cond("construction",
         "Restrictions noted alongside: the generalization concerns availability across a "
         "lexical category, not unrestricted acceptability in every sentence frame; material "
         "before a determiner falls outside the independent-use comparison, so predeterminer "
         "\\mention{all} in \\mention{all the books} is excluded from it; and Hudson's criteria "
         "set \\mention{all} aside, leaving its place in that taxonomy unsettled."),
], [E("M", MQ["cgel_indep_list"]), E("M", MQ["all_agree"]), E("M", MQ["cgel_indep_gen"]),
    E("M", MQ["predet_all"]), E("M", MQ["hudson_aside"])])

claim("X091", "lex_both", "independent_argument", "licensed", [
    cond("construction",
         "Attested object use in the sentence \\mention{Went there yesterday: we are trying to "
         "decide between two different Honda models, so we wanted to test-drive both back to "
         "back.}"),
    cond("construction",
         "Provenance and verification: English Web Treebank sentence reviews-083459-0002, "
         "verified in the UD English EWT training data, with syntactic annotation supplied by "
         "CGELBank; the original review webpage wasn't identified."),
    cond("construction",
         "Domain: the phrase \\mention{two different Honda models} supplies the domain for the "
         "independent object \\mention{both}."),
], [E("M", MQ["both_attested"]), E("M", MQ["both_domain"]), E("M", MQ["both_prov"])])

claim("X092", "lex_that", "independent_argument", "licensed", [
    cond("construction",
         "Basis for the description: \\mention{those who came} is listed among determinative "
         "examples of relative-clause postmodification, and \\textit{CGEL} is cited as "
         "describing relative postmodification with demonstratives and compounds."),
    cond("own_phrase",
         "Kind of postmodifier: an integrated relative clause of the kind common nouns take "
         "freely in \\mention{people who came}; in the fragment these are ordinary "
         "postmodifiers, distinct from the compounds' specialized post-head restrictor, and "
         "the fragment admits them without analysing their internal grammar."),
    cond("own_phrase",
         "Form: \\mention{those} is the plural form of the demonstrative lexeme, whose number "
         "contrast \\mention{that}/\\mention{those} remains visible in independent uses."),
], [E("M", MQ["those"]), E("M", MQ["rel_cgel"]), E("M", MQ["rel_integrated"]),
    E("M", MQ["rel_ordinary"]), E("M", MQ["dem_number"])])

claim("X093", "lex_anyone", "internal_mod_admission", "licensed", [
    cond("own_phrase",
         "Specialized function: the post-head adjective realizes a specialized restrictor "
         "function."),
    cond("own_phrase",
         "Position and recursion: the restrictor is restricted to post-head position and is "
         "non-recursive; the compound construction permits at most one specialized post-head "
         "restrictor, followed by ordinary postmodifiers."),
    cond("construction",
         "Attachment: in the ordinary-Head analysis \\mention{present} is internal to the Nom, "
         "and the compound construction independently supplies this internal post-head "
         "restrictor permission; in the fusion account of \\textcite{Payne2007}, "
         "\\mention{present} likewise belongs to nominal structure."),
], [E("M", MQ["restrictor"]), E("M", MQ["compound_perm"]), E("M", MQ["hardly_anyone"]),
    E("M", MQ["order_frag"])])

claim("X094", "lex_anyone", "peripheral_mod_admission", "licensed", [
    cond("outer_np",
         "Attachment in the ordinary-Head account: \\mention{hardly} is peripheral to the NP, "
         "following the approximative pattern and its NP parallels, while \\mention{present} "
         "is internal to the Nom."),
    cond("own_phrase",
         "Source of the premodifier permissions: the compound inherits nominal projection from "
         "Noun and its premodifier permissions from its determinative base \\mention{any}; "
         "compare \\mention{hardly any writer present}."),
    cond("construction",
         "How the fusion account differs: \\textcite{Payne2007} assign \\mention{hardly} to DP "
         "structure, so fusion groups \\mention{hardly anyone} in DP, whereas ordinary Head "
         "groups \\mention{anyone present} in the inner NP; both accounts separate the modifier "
         "domains structurally."),
    SCOPE_ANALYTIC,
], [E("M", MQ["hardly_anyone"]), E("M", MQ["ordinary_head_tree"]), E("M", MQ["grouping_diff"]),
    E("M", MQ["analytic"])])

claim("X095", "lex_anyone", "independent_argument", "licensed", [
    cond("construction",
         "Basis: compounds are reported to permit \\mention{anyone who asks} and "
         "\\mention{everything that matters}, and \\textit{CGEL} is cited for relative "
         "postmodification with demonstratives and compounds, giving compounds the common "
         "noun's range of ordinary postmodifiers."),
    cond("own_phrase",
         "External determination: the compound construction independently excludes external "
         "determination (and a corresponding pre-head adjective), so no external determiner is "
         "available in this construction."),
], [E("M", MQ["compounds_rel"]), E("M", MQ["rel_cgel"]), E("M", MQ["compound_perm"]),
    E("M", MQ["order_frag"]), E("M", MQ["compounds_cgel_post"])])

claim("X096", "lex_something", "internal_mod_admission", "licensed", [
    cond("own_phrase",
         "Ordering condition: when both occur, the ordinary relative postmodifier follows the "
         "specialized post-head restrictor, as in \\mention{something useful that I found}; the "
         "compounds permit at most one specialized post-head restrictor followed by ordinary "
         "postmodifiers."),
    cond("own_phrase",
         "Position and interpretation of the post-head adjectival material have specialized "
         "conditions; \\mention{I need something reliable and good looking} illustrates the "
         "post-head pattern."),
], [E("M", MQ["order_rel"]), E("M", MQ["order_frag"]), E("M", MQ["something_posthead"])])

claim("X097", "lex_something", "internal_mod_admission", "excluded", [
    cond("construction",
         "What the compound construction licenses: it supplies the internal post-head "
         "restrictor permission but doesn't license a corresponding pre-head adjective; the "
         "compounds exclude external determination and a corresponding pre-head adjective."),
    cond("construction",
         "The same division is stated for \\mention{someone} and \\mention{everybody}: the "
         "compound construction licenses the post-head restrictor, while the determinative base "
         "supplies the premodifier permissions."),
], [E("M", MQ["compound_perm"]), E("M", MQ["order_frag"]), E("M", MQ["someone_division"])])

claim("X098", "lex_lot", "independent_argument", "licensed", [
    cond("construction",
         "Stated frame: the article belongs to the frame \\mention{a lot of delegates}, not to "
         "the lexeme's form."),
    cond("own_phrase",
         "Undetermined complement: \\mention{lot} permits an \\mention{of}-PP whose complement "
         "is an undetermined nominal, \\mention{a lot of delegates}; this is kept distinct from "
         "the partitive \\mention{a lot of the delegates}, where the head quantifies over a "
         "partitive domain, the whole from which a quantity is drawn."),
    cond("own_phrase",
         "Number transparency: \\textit{CGEL} calls quantificational \\mention{lot} "
         "number-transparent; the whole subject NP's number depends on the complement of "
         "\\mention{of}, with plural agreement in \\mention{A lot of the people were waiting} "
         "and singular agreement in \\mention{A lot of the work was finished}."),
    cond("construction",
         "Contrast drawn: the same undetermined complement is excluded for \\mention{many}, so "
         "the two differ despite both quantifying over a partitive domain."),
], [E("M", MQ["lot_delegates"]), E("M", MQ["agreement"]), E("M", MQ["number_transp"])])

claim("X099", "lex_many", "independent_partitive", "excluded", [
    cond("own_phrase",
         "The excluded sequence is \\mention{many of delegates}, with an undetermined nominal "
         "as complement of \\mention{of}; the partitive \\mention{many of the delegates}, with "
         "a determined complement, is not excluded and quantifies over a partitive domain."),
    cond("construction",
         "Contrast with the quantificational common noun: \\mention{lot} also permits "
         "\\mention{a lot of delegates}, whereas the corresponding sequence with "
         "\\mention{many} is excluded; this is the point at which the common noun and the "
         "determinative diverge in the manuscript's comparison."),
], [E("M", MQ["lot_delegates"])])

# X100: the source says only that quantificational \mention{plenty} is a common noun
# "whose use resists determination and modification". "Resists" establishes neither a
# permission nor a ban, and no fixed status expresses it, so the record asserts neither
# polarity: not_stated, with empty conditions and evidence as the schema requires. The
# two distinct source restrictions (modification, determination) are kept, unmerged, in
# exceptions.json, where the participation judgment is recorded as unresolved.
claim("X100", "lex_plenty", "internal_mod_admission", "not_stated", [], [])

claim("X101", "lex_lot", "internal_mod_admission", "licensed", [
    cond("own_phrase",
         "Stated limit on modification: \\mention{lot} permits only limited modification; the "
         "documents state no inventory of the admitted modifiers within its own phrase."),
    cond("construction",
         "Separate requirement for the article: \\mention{lot} requires \\mention{a}; the "
         "article is carried here as a condition on the use, and the lexeme record keeps the "
         "bare form \\mention{lot}."),
    cond("construction",
         "Role in the argument: restricted dependents on the common-noun side show established "
         "common nouns approaching the determinative profile."),
], [E("M", MQ["plenty_lot_restr"]), E("M", MQ["approach_profile"])])

claim("X102", "lex_some", "independent_partitive", "licensed", [
    cond("own_phrase",
         "Domain expression: the partitive domain is denoted by the NP complement of "
         "\\mention{of}; it may be an ordinary NP (\\mention{the wine}), a pronoun-headed NP "
         "(\\mention{many of them}), or an independent genitive NP (\\mention{some of Kim's})."),
    cond("construction",
         "Agreement: the whole subject NP's number depends on the complement of \\mention{of}, "
         "giving plural \\mention{Some of the people were waiting} and singular \\mention{Some "
         "of the work was finished}; number transparency connects quantificational "
         "\\mention{lot} with number-neutral \\mention{some}."),
    cond("own_phrase",
         "Head relations assigned: the \\mention{of}-phrase functions as complement within Nom, "
         "and the Head relations lead from the outer NP to \\mention{some}, which is the "
         "ultimate lexical head; \\mention{wine} is inside the complement PP and doesn't head "
         "the whole expression. The manuscript's preferred analysis gives \\mention{some} "
         "ordinary Head, where \\textit{CGEL} has its DP fill Det--Head."),
    cond("construction",
         "In Det or internal Mod function before a target, ordinary \\mention{some} excludes "
         "partitive complements; the partitive belongs to the independent use."),
], [E("M", MQ["some_partitive"]), E("M", MQ["agreement"]), E("M", MQ["number_transp"]),
    E("M", MQ["partitive_head"]), E("M", MQ["partitive_fig"]), E("M", MQ["dep_excl"])])

claim("X103", "lex_several", "predicative_complement", "licensed", [
    cond("construction",
         "Evidential basis: \\textit{CGEL}'s description, cited for predicative \\mention{Its "
         "advantages are several} as further overlap between the determinative and adjective "
         "ranges."),
    cond("construction",
         "Scope caveat: the manuscript's fragment places predication beyond its scope, so this "
         "record rests on the §2.3 discussion rather than on the fragment's permissions; "
         "\\textit{CGEL} is also reported to exclude specifying \\mention{be} clauses from its "
         "noun--adjective diagnostic because phrases from other categories occur in them."),
], [E("M", MQ["predicative"]), E("M", MQ["fragment_scope"]), E("M", MQ["fragment_covers"]),
    E("M", MQ["specifying_be"])])

claim("X104", "lex_many", "predicative_complement", "licensed", [
    cond("construction",
         "Evidential basis: \\textit{CGEL}'s description, cited for predicative \\mention{Their "
         "enemies were many}."),
    cond("own_phrase",
         "Frequency and register qualification stated for this example: it is uncommon and "
         "formal."),
    cond("construction",
         "Scope caveat: the manuscript's fragment places predication beyond its scope, so this "
         "record rests on the §2.3 discussion rather than on the fragment's permissions."),
], [E("M", MQ["predicative"]), E("M", MQ["fragment_scope"]), E("M", MQ["fragment_covers"])])

claim("X105", "lex_my", "predicative_complement", "licensed", [
    cond("own_phrase",
         "Reading distinguished: predicative \\mention{mine} in \\mention{it's mine} can mean "
         "'belongs to me', expressing the possessive relation directly and without an "
         "understood nominal head; this contrasts with anaphoric \\mention{mine}, understood as "
         "'my car', which combines the relation with an understood nominal description and "
         "receives a fused analysis in \\textit{CGEL}."),
    cond("construction",
         "Either reading may be available: a suitable context may permit either."),
    cond("own_phrase",
         "Head analysis preferred: the manuscript gives \\mention{mine} ordinary Head in both "
         "anaphoric and predicative uses; \\mention{my}/\\mention{mine} remains a form-selection "
         "condition, parallel to \\mention{no}/\\mention{none}."),
    cond("possessed_referent",
         "Agreement: the genitive's person identifies the possessor, while the independent NP's "
         "agreement reflects the possessed entity or entities, as in \\mention{Mine is ready} "
         "versus \\mention{Mine are ready}; ordinary Head therefore needs a constructional "
         "agreement condition."),
    cond("construction",
         "Scope caveat: the fragment places predication beyond its scope."),
], [E("M", MQ["mine_pred"]), E("M", MQ["mine_anaph"]), E("M", MQ["mine_either"]),
    E("M", MQ["mine_ordinary"]), E("M", MQ["mine_agreement"]), E("M", MQ["my_paradigm"]),
    E("M", MQ["fragment_scope"])])

claim("X106", "lex_a", "dependent_det", "licensed", [
    cond("target_nominal",
         "Target selection: \\mention{a} selects a singular count target; the fragment's "
         "permissions table records Det \"yes\" for \\mention{a} with the target restriction "
         "\"Singular count\"."),
    cond("own_phrase",
         "Contribution to interpretation: \\mention{a} contributes individuation, and the "
         "articles contribute to the interpretation of the NP within the determinative system "
         "of definiteness, quantity, and count restrictions."),
    cond("own_phrase",
         "Restriction on other uses: \\mention{a} has no independent argument form; its "
         "positive evidence is integration into the determinative system."),
], [E("M", MQ["article_targets"]), E("M", MQ["a_row"]), E("M", MQ["article_system"]),
    E("M", MQ["article_noindep"])])

claim("X107", "lex_many", "dependent_det", "licensed", [
    cond("target_nominal",
         "Target selection: the documents state no count or number target restriction for "
         "\\mention{many}; the fragment's permissions table records targets for "
         "\\mention{the}, \\mention{a}, \\mention{every}, \\mention{some}, \\mention{few}, "
         "\\mention{no}, \\mention{none}, \\mention{my}, \\mention{mine}, \\mention{she} and "
         "\\mention{her}, and has no row for \\mention{many} (see exceptions.json)."),
    cond("construction",
         "Degree-modification evidence separating \\mention{many} from an attributive "
         "adjective: \\mention{so many mistakes} is possible while \\mention{so numerous "
         "mistakes} is excluded, so quantity meaning and prenominal position are held constant "
         "as a semantic control while the syntax differs."),
    cond("own_phrase",
         "\\mention{Many} is one of the four determinatives that inflect for grade and that the "
         "degree series selects."),
], [E("M", MQ["many_numerous"]), E("M", MQ["numerous_so"]), E("M", MQ["semantic_control"]),
    E("M", MQ["series"]), E("M", MQ["perm_header"])])

claim("X108", "lex_numerous", "dependent_internal_mod", "licensed", [
    cond("own_phrase",
         "Category assigned: \\mention{numerous} is treated as a quantificational adjective "
         "used attributively before the nominal; the manuscript's §2.3 is headed "
         "\"Quantificational adjectives and nominal independence\" and contrasts its syntax "
         "with that of determinative \\mention{many}."),
    cond("construction",
         "Role of the control: quantity meaning and prenominal position provide a semantic "
         "control for the nominal comparison, so that independent use can test whether further "
         "distributions sustain the distinction; assigning every independent quantity word to "
         "determinative would make independent use a circular category diagnostic."),
    cond("construction",
         "Independent uses nevertheless extend to \\mention{numerous}, \\mention{multiple}, and "
         "\\mention{countless}; the selected occurrences establish overlap without establishing "
         "equal acceptability or frequency."),
], [E("M", MQ["quant_adj_head"]), E("M", MQ["many_numerous"]), E("M", MQ["numerous_so"]),
    E("M", MQ["semantic_control"]), E("M", MQ["indep_quant_extend"]), E("M", MQ["circular"])])

claim("X109", "lex_rich", "independent_argument", "licensed", [
    cond("outer_np",
         "Determination requirement: on the generic human reading, an NP with \\mention{rich} "
         "as fused head requires the definite article \\mention{the}."),
    cond("outer_np",
         "Number and agreement: generic human \\mention{the rich} is a plural NP and takes "
         "plural agreement."),
    cond("own_phrase",
         "The fused-head adjective lacks number inflection and still takes adverb modifiers, "
         "as in \\mention{the very rich}."),
    cond("construction",
         "Contrast drawn: independent \\mention{some} can form a one-word NP, whereas the "
         "generic human reading of \\mention{rich} requires \\mention{the}; the manuscript "
         "calls this a local contrast, since argument NPs headed by singular count common nouns "
         "also need determination, and notes that fused-head AdjPs prevent a simple inference "
         "from argument positions to nounhood."),
], [E("M", MQ["rich_det"]), E("M", MQ["rich_local"]), E("M", MQ["rich_plural"]),
    E("M", MQ["rich_agree"]), E("M", MQ["rich_fused"])])

claim("X110", "lex_second", "existential_displaced_subject", "licensed", [
    cond("construction",
         "Evidential basis: a constructed comparison, \\mention{There was a second}, built on "
         "\\textit{CGEL}'s statement that adjective fusion permits the indefinite ordinal "
         "\\mention{a second}."),
    cond("construction",
         "What existential occurrence does and does not decide: it doesn't decide the structural "
         "analysis; the example is the manuscript's control against inferring category or Head "
         "relations from occurrence in the existential construction. Plural agreement likewise "
         "occurs with adjective-containing \\mention{the rich}."),
    cond("construction",
         "The displaced-subject analysis, with dummy \\mention{there} as subject, is "
         "\\textit{CGEL}'s."),
], [E("M", MQ["second"]), E("M", MQ["exist_nodecide"]), E("M", MQ["exist_several"]),
    E("M", MQ["rich_agree"])])

# ------------------------------------- source support for table-cell claims ---
# Four cells in the X001-X054 block state facts that the generated evidence did not
# quote: the manuscript's own constructed existential with \mention{several} (X012),
# and the supplement's running-text statements about the anaphoric interpretations of
# bare existential \mention{numerous} and \mention{countless} (X030, X042) and about
# the register of the \mention{countless} partitive (X037).
Q_ANAPHORIC_CONTEXTS = ("The final two have no NP dependent: \\mention{numerous} refers to "
                        "benefits of a college education and \\mention{countless} to investment "
                        "options. These contexts establish anaphoric interpretations without an "
                        "overt following nominal.")
Q_COUNTLESS_REGISTER = ("The \\mention{countless} partitive comes from academic prose; the "
                        "\\mention{multiple} partitive from a blog discussion.")

BY_ID = {c["id"]: c for c in participation}


def add_evidence(qid, source_id, quote):
    rec = BY_ID[qid]
    if not any(e["source_id"] == source_id and e["quote"] == quote for e in rec["evidence"]):
        rec["evidence"].append(ev(source_id, quote))


def add_condition(qid, bearer, requirement):
    BY_ID[qid]["conditions"].append(cond(bearer, requirement))


# X012: the manuscript's constructed \mention{There are several} bears on this cell and is
# kept distinct from the supplement's own \textit{I} cell for the frame "Are there several?".
add_condition("X012",
              "construction",
              "Separate statement in the manuscript bearing on this cell: with possible "
              "solutions under discussion, the constructed \\mention{There are several} places "
              "the independent quantifier in displaced-subject position, with dummy "
              "\\mention{there} as subject; the manuscript attributes that displaced-subject "
              "analysis to \\textit{CGEL} 1391--1393. This is the manuscript's own constructed "
              "example and is recorded separately from the supplement's constructed "
              "illustration in the stated frame \"Are there several?\".")
add_evidence("X012", "M", MQ["exist_several"])
add_evidence("X030", "Q", Q_ANAPHORIC_CONTEXTS)
add_evidence("X042", "Q", Q_ANAPHORIC_CONTEXTS)
add_evidence("X037", "Q", Q_COUNTLESS_REGISTER)

# ------------------------------------------------------------ scope checks ---
scope_checks = [
    {
        "id": "one_lexeme_split",
        "answer": (
            "Three separate lexeme records. The manuscript reports, following the cited "
            "analysis, three distinct lexemes spelled \\mention{one} - determinative, anaphoric "
            "common noun, and generic personal pronoun - and says they remain distinct under "
            "the D-noun categorization while all belonging within primary Noun. Shared spelling "
            "is therefore homography across three lexemes, not three forms of one lexeme, so a "
            "single record with several forms would conflate them, against the instruction not "
            "to conflate homographs; the shared membership in Noun is a taxonomic statement "
            "about three lexemes, not a form-paradigm relation, and no such relation is stated. "
            "No lexeme id for \\mention{one} is in the fixed inventory, so no record is created "
            "here; the answer is recorded as a scope answer only."),
        "evidence": [
            ev("M", MQ["one_lexemes"]),
            ev("M", MQ["one_anaphoric"]),
            ev("M", MQ["one_grouping"]),
        ],
    },
    {
        "id": "lots_heaps_lexeme_identity",
        "answer": (
            "No. Neither document states whether \\mention{lots} in \\mention{lots better} and "
            "\\mention{heaps} in \\mention{heaps worse} are forms of quantificational "
            "\\mention{lot} and \\mention{heap} or separate lexemes. What is stated is only that "
            "\\textit{CGEL} treats these two expressions as containing quantificational NP "
            "modifiers, and that informal attributive examples with nominal \\mention{heaps} and "
            "\\mention{lots} qualify a categorical exclusion. It follows that the provisional "
            "records lex_lots and lex_heaps are kept separate from lex_lot, carry only the forms "
            "\\mention{lots} and \\mention{heaps}, and must not be merged into lex_lot or into "
            "any lexeme \\mention{heap} without a source statement; the claims recorded under "
            "them (X077-X080) transfer no permission to lex_lot. The unresolved identity is also "
            "flagged in exceptions.json."),
        "evidence": [
            ev("M", MQ["cgel_lots_heaps"]),
            ev("M", MQ["informal_attr"]),
            ev("M", MQ["informal_note"]),
        ],
    },
    {
        "id": "completeness_modifier_attachment",
        "answer": (
            "No attachment site is stated, and no record using the internal or peripheral "
            "modifier constructions can be completed for them without supplying an unstated "
            "analysis. The manuscript mentions \\mention{marginally enough} and "
            "\\mention{absolutely all} only as \\textit{CGEL}-recorded modifiers of completeness "
            "with different selectional ranges, and only in order to deny that they extend the "
            "\\mention{very}/\\mention{so}/\\mention{too}/\\mention{how} series beyond the four "
            "degree determinatives. Attachment sites are assigned elsewhere - internal for the "
            "degree series and for approximatives on externally determined cardinals, peripheral "
            "for approximatives such as \\mention{almost every} - but nothing is said about "
            "where a completeness modifier attaches. Choosing internal_mod_admission or "
            "peripheral_mod_admission would therefore be an analysis of ours rather than an "
            "extraction, so no participation claim is made for these two combinations."),
        "evidence": [
            ev("M", MQ["completeness_mods"]),
            ev("M", MQ["completeness_no_ext"]),
            ev("M", MQ["two_sites"]),
        ],
    },
    {
        "id": "search_nonfinding_vs_unstated",
        "answer": (
            "No, the fixed vocabulary does not distinguish them. The four S cells (argument "
            "\\mention{certain} with a relative, bare existential \\mention{certain}, "
            "existential \\mention{various} with a relative, and existential \\mention{various} "
            "with no dependent) record a bounded search in which no qualifying attestation was "
            "retained; the supplement says explicitly that this isn't an ungrammaticality "
            "judgment, that the bounded searches don't establish exclusion, and that these cells "
            "retain a different evidential status both from the positive examples and from "
            "\\textit{CGEL}'s stated restrictions. Among the fixed statuses, licensed would "
            "report a positive result and excluded would convert a nonfinding into a ban, so "
            "these four records take not_stated - the same value a combination the documents "
            "never address would take. Since not_stated records must carry empty conditions and "
            "evidence, the distinction is recorded outside the record shape: in exceptions.json, "
            "one entry per cell (X014, X018, X023, X024), each carrying the supplement's own "
            "wording and the bounds of the searches. One further record, X100, also takes "
            "not_stated for a different reason - the source's \"resists\" wording supports "
            "neither polarity - so not_stated in these records covers three distinct situations "
            "that the status field itself cannot tell apart; the X100 entry in exceptions.json "
            "states which one applies there."),
        "evidence": [
            ev("Q", Q_NONFINDING),
            ev("Q", Q_CAPTION),
            ev("Q", Q_SEARCHDATE),
        ],
    },
    {
        "id": "predication_outside_fragment",
        "answer": (
            "Records built on predicative_complement (X103-X105) have the scope of the "
            "manuscript's §2.3 profile discussion and of the \\textit{CGEL} statements it cites, "
            "not of the fragment's use permissions. The fragment covers determination, internal "
            "nominal modification, ordinary subject, object and complement-of-preposition uses, "
            "partitives and the compound comparisons, and explicitly places predication, "
            "interrogative clause structure and modification outside NP structure beyond its "
            "scope; nothing in its permissions table licenses or excludes these predicative "
            "uses. They are cited as evidence in the profile comparison: predicative "
            "\\mention{Its advantages are several} and \\mention{Their enemies were many} as "
            "overlap with adjectives (the latter uncommon and formal), and predicative "
            "\\mention{mine} for the Head analysis of independent genitives. The caveat also "
            "limits what such records support: \\textit{CGEL} excludes specifying \\mention{be} "
            "clauses from its noun-adjective diagnostic, and NP and AdjP share predicative "
            "complement function, so predicative occurrence alone establishes no category. These "
            "three records carry that caveat in their conditions; no other construction in this "
            "batch does."),
        "evidence": [
            ev("M", MQ["fragment_covers"]),
            ev("M", MQ["fragment_scope"]),
            ev("M", MQ["predicative"]),
            ev("M", MQ["specifying_be"]),
            ev("M", MQ["pred_np_adjp"]),
        ],
    },
    {
        "id": "attestation_scope_limits",
        "answer": (
            "They support the occurrence, and nothing beyond it. Each positive attestation "
            "establishes that the recorded expression occurred in the recorded source, in the "
            "cell's dependent type and surrounding construction, subject to the verification "
            "limits stated for that record. The supplement states that the searches establish "
            "selected occurrences without estimating their frequency, supply no usage rates, "
            "establish no ordering of the constructions, and that source locations don't "
            "establish each speaker's or writer's variety; the manuscript adds that such "
            "selected occurrences establish overlap without establishing equal acceptability or "
            "frequency. The attestation records therefore support no claim about how common a "
            "use is, no ranking of the partitive, relative and bare cells against one another, "
            "no attribution of a use to a dialect or speaker group, and no inference about "
            "general acceptability. Per-record verification limits narrow this further: "
            "unavailable original pages, a URL returning an error page, quotations checked "
            "without audio, reported speech whose original language wasn't established, an "
            "author and date that remain unverified, a source verified only through a secondary "
            "draft, and a NOW record date differing from the page's update date. The searches "
            "themselves were bounded: 12-13 September 2026, in NOW and COCA, using surface "
            "strings without part-of-speech filters."),
        "evidence": [
            ev("Q", Q_ORDERING),
            ev("Q", Q_RATES),
            ev("Q", Q_VARIETY),
            ev("Q", Q_SEARCHDATE),
            ev("M", MQ["circular"]),
        ],
    },
]

# -------------------------------------------------------------- exceptions ---
exceptions = [
    {
        "query_id": "X014",
        "reason": ("Fixed status vocabulary cannot express a bounded search that retained no "
                   "qualifying attestation. The supplement's table marks this cell S, defined as "
                   "\"searched, with no qualifying attestation retained; this isn't an "
                   "ungrammaticality judgment\", and states that the bounded searches don't "
                   "establish exclusion and that these cells retain a different evidential status "
                   "from the positive examples and from CGEL's stated restrictions. \"excluded\" "
                   "would convert the nonfinding into a ban and \"licensed\" would report a "
                   "positive result, so the record uses \"not_stated\", which cannot be "
                   "distinguished from a combination the documents never address. Because "
                   "not_stated records carry empty conditions and evidence, the supplement's "
                   "qualifications are preserved here instead. The searches were bounded: 12-13 "
                   "September 2026, NOW and COCA, surface strings without part-of-speech filters."),
        "evidence": [ev("Q", qrow("certain")), ev("Q", Q_CAPTION), ev("Q", Q_NONFINDING),
                     ev("Q", Q_SEARCHDATE)],
    },
    {
        "query_id": "X018",
        "reason": ("Same limitation as X014, for the bare existential \\mention{certain} cell "
                   "(frame \"Are there certain?\"). The table marks it S; the supplement names it "
                   "among the four cells for which no qualifying attestation was retained, states "
                   "that the bounded searches don't establish exclusion, and separates the cell's "
                   "evidential status both from the positive examples and from CGEL's stated "
                   "restrictions. The record is not_stated with empty conditions and evidence, so "
                   "those qualifications are preserved here."),
        "evidence": [ev("Q", qrow("certain")), ev("Q", Q_CAPTION), ev("Q", Q_NONFINDING),
                     ev("Q", Q_SEARCHDATE)],
    },
    {
        "query_id": "X023",
        "reason": ("Same limitation as X014, for existential \\mention{various} with a relative "
                   "clause (frame \"There are various who can help\"). The table marks it S, and "
                   "the supplement names it among the four cells for which no qualifying "
                   "attestation was retained and states that the bounded searches don't establish "
                   "exclusion. Recorded as not_stated, with the supplement's qualifications "
                   "preserved here."),
        "evidence": [ev("Q", qrow("various")), ev("Q", Q_CAPTION), ev("Q", Q_NONFINDING),
                     ev("Q", Q_SEARCHDATE)],
    },
    {
        "query_id": "X024",
        "reason": ("Same limitation as X014, for existential \\mention{various} with no dependent "
                   "(frame \"Are there various?\"). The table marks it S, and the supplement names "
                   "it among the four cells for which no qualifying attestation was retained and "
                   "states that the bounded searches don't establish exclusion. Recorded as "
                   "not_stated, with the supplement's qualifications preserved here."),
        "evidence": [ev("Q", qrow("various")), ev("Q", Q_CAPTION), ev("Q", Q_NONFINDING),
                     ev("Q", Q_SEARCHDATE)],
    },
    {
        "query_id": "X015",
        "reason": ("R cell: the status field cannot carry a stated restriction. The supplement "
                   "marks independent \\mention{certain} with no dependent R, \"restricted "
                   "there\", i.e. restricted in CGEL, because the of-phrase with independent "
                   "certain and various is hardly omissible. \"excluded\" would strengthen that "
                   "restriction into a categorical ban and \"licensed\" alone would drop it, so "
                   "the record uses \"licensed\" and carries the restriction as an own_phrase "
                   "condition; a reader of the status field alone cannot recover it. The "
                   "restriction is not generalized beyond this cell."),
        "evidence": [ev("Q", qrow("certain")), ev("Q", Q_CAPTION), ev("Q", Q_CGEL_RESTR),
                     ev("Q", Q_GR)],
    },
    {
        "query_id": "X021",
        "reason": ("R cell: same limitation as X015, for independent \\mention{various} with no "
                   "dependent. The supplement marks the cell R and states that the of-phrase with "
                   "independent certain and various is hardly omissible. The record uses "
                   "\"licensed\" with the restriction as an own_phrase condition rather than "
                   "converting a restriction into an exclusion; the status field itself cannot "
                   "carry the distinction, and the restriction is not generalized beyond this "
                   "cell."),
        "evidence": [ev("Q", qrow("various")), ev("Q", Q_CAPTION), ev("Q", Q_CGEL_RESTR),
                     ev("Q", Q_GR)],
    },
    {
        "query_id": "X013",
        "reason": ("Evidential basis has no field of its own. The cell is a G cell, a CGEL "
                   "description carrying the register restriction that the partitive with certain "
                   "is relatively formal, and CGEL treats quantificational certain as a marginal "
                   "member of the determinative category. The status \"licensed\" reports "
                   "participation only; the restriction and the evidential basis ride in "
                   "conditions and evidence, and are not generalized beyond this cell. The same "
                   "limitation applies to the corresponding various cell, X019, whose partitive is "
                   "accepted by some speakers, primarily in American English."),
        "evidence": [ev("Q", qrow("certain")), ev("Q", qrow("various")), ev("Q", Q_CGEL_RESTR),
                     ev("Q", Q_CAPTION)],
    },
    {
        "query_id": "X077",
        "reason": ("Lexeme identity unresolved. The query is recorded under the provisional lexeme "
                   "lex_lots, but neither document states whether \\mention{lots} is a form of the "
                   "quantificational lexeme \\mention{lot} or a separate lexeme. The record "
                   "therefore keeps lex_lots separate from lex_lot, and the permission recorded "
                   "here transfers to neither. The same applies to X078, and to \\mention{heaps} "
                   "in X079-X080 with respect to any lexeme \\mention{heap}. See the "
                   "lots_heaps_lexeme_identity scope check."),
        "evidence": [ev("M", MQ["cgel_lots_heaps"]), ev("M", MQ["informal_attr"])],
    },
    {
        "query_id": "X078",
        "reason": ("Two issues. (i) Lexeme identity, as for X077: lex_lots is provisional and no "
                   "source statement relates \\mention{lots} to \\mention{lot}. (ii) Evidential "
                   "basis: the attributive example rests on an informal forum attestation whose "
                   "author and date remain unverified and which was verified only in an indexed "
                   "excerpt; the source states that any register restriction remains to be "
                   "established and that such examples don't establish the same distribution as "
                   "degree determinatives. The status \"licensed\" records the attested occurrence "
                   "only, and the record shape has no evidential-basis field, so this rides in "
                   "conditions."),
        "evidence": [ev("M", MQ["lots_att"]), ev("M", MQ["informal_note"]),
                     ev("M", MQ["informal_limits"])],
    },
    {
        "query_id": "X080",
        "reason": ("As for X078, for \\mention{heaps}: lex_heaps is provisional, and the "
                   "attributive example is an informal forum attestation (AULRO, moose, 19 August "
                   "2008, post 2) with the original spelling retained, of which the source says "
                   "that any register restriction remains to be established and that it doesn't "
                   "establish the same distribution as degree determinatives. The status "
                   "\"licensed\" records the attested occurrence only."),
        "evidence": [ev("M", MQ["heaps_att"]), ev("M", MQ["informal_note"]),
                     ev("M", MQ["informal_limits"])],
    },
    {
        "query_id": "X100",
        "reason": ("Participation unresolved; no fixed status expresses the source wording. The "
                   "only relevant statement is that \\textit{CGEL} categorizes quantificational "
                   "\\mention{plenty} as \"a common noun whose use resists determination and "
                   "modification\". \"Resists\" is a negative-leaning restriction that "
                   "establishes no positive availability, unlike \\mention{lot}'s \"permits only "
                   "limited modification\" (X101) or the hardly-omissible \\mention{of}-phrase "
                   "cells (X015, X021), whose source wording is permissive or presupposes an "
                   "available use; equally, no ungrammaticality judgment or starred example is "
                   "given for modified \\mention{plenty}. \"licensed\" and \"excluded\" would "
                   "each assert a polarity the source does not support, so the record is "
                   "\"not_stated\" with empty conditions and evidence, as the fixed schema "
                   "requires for that status. That choice is made only to avoid asserting either "
                   "polarity: it does not mean the documents are silent on modification of "
                   "\\mention{plenty}, and the participation judgment for modification within "
                   "quantificational \\mention{plenty}'s own phrase remains unresolved. Two "
                   "distinct source restrictions therefore survive only here, unmerged: (i) the "
                   "modification restriction, that the use resists modification; and (ii) the "
                   "separate determination restriction, that the same use resists determination. "
                   "No other passage shows modification within quantificational "
                   "\\mention{plenty}'s own phrase; \\mention{plenty big enough} is a "
                   "degree-modifier use of \\mention{plenty}, not modification of it."),
        "evidence": [ev("M", MQ["plenty_lot_restr"])],
    },
    {
        "query_id": "X109",
        "reason": ("Bearer convention not fixed by the schema. The schema does not state whether "
                   "the participant phrase in independent_argument for a fused head is the AdjP "
                   "headed by \\mention{rich} or the containing NP \\mention{the rich}. This "
                   "record takes own_phrase to be the fused-head AdjP and outer_np the containing "
                   "NP, matching its determination condition, and splits the source's properties "
                   "accordingly: plural NP status and plural agreement are properties of the NP "
                   "(outer_np), while the absence of number inflection and the admission of "
                   "adverb modifiers are properties of the adjective (own_phrase). If the "
                   "extraction instead treated the NP as own_phrase, the determination condition "
                   "would have to move there and outer_np would be dropped; either way the two "
                   "levels must not be bundled into one condition."),
        "evidence": [ev("M", MQ["rich_det"]), ev("M", MQ["rich_plural"]),
                     ev("M", MQ["rich_agree"]), ev("M", MQ["rich_fused"])],
    },
    {
        "query_id": "X087",
        "reason": ("Part of the request cannot be answered from the sources. The query asks for any "
                   "target selection stated for \\mention{enough} before a nominal; the documents "
                   "state only that \\mention{enough} precedes a nominal in \\mention{enough money} "
                   "and can follow one in \\mention{money enough}, and the fragment's permissions "
                   "table, which is where target restrictions are recorded, has no row for "
                   "\\mention{enough}. The participation claim itself is recorded as licensed; the "
                   "target-selection sub-request is unresolved in the sources and is not answered "
                   "by inference. A further limitation: post-head \\mention{enough} in "
                   "\\mention{money enough} has no faithful construction here, since dependent_det "
                   "and dependent_internal_mod are both defined as occurring before a separate "
                   "target nominal, so only the premodification test (X088) could be recorded."),
        "evidence": [ev("M", MQ["enough_pos"]), ev("M", MQ["perm_header"])],
    },
    {
        "query_id": "X107",
        "reason": ("Part of the request cannot be answered from the sources. The query asks for the "
                   "target selection of \\mention{many} as Det; the fragment's permissions table "
                   "records target restrictions only for \\mention{the}, \\mention{a}, "
                   "\\mention{every}, \\mention{some}, \\mention{few}, \\mention{no}, "
                   "\\mention{none}, \\mention{my}, \\mention{mine}, \\mention{she} and "
                   "\\mention{her}, and neither document states a count or number target "
                   "restriction for \\mention{many}. The degree-modification part of the request is "
                   "answered in full, and the participation claim is recorded as licensed."),
        "evidence": [ev("M", MQ["perm_header"]), ev("M", MQ["many_numerous"]),
                     ev("M", MQ["numerous_so"])],
    },
    {
        "query_id": "X062",
        "reason": ("Lexeme assignment unsettled for the complex determinative. The documents call "
                   "\\mention{a few} a complex determinative, say that its initial \\mention{a} "
                   "isn't an ordinary Det selecting a plural \\mention{few} target, and leave its "
                   "internal analysis beyond the position contrast unspecified. The record uses "
                   "lex_few with the article kept in the frame and conditions, as the query "
                   "directs, but whether the bearer of this permission is the lexeme "
                   "\\mention{few} or the complex unit \\mention{a few} is not settled by the "
                   "sources. The same applies to X063."),
        "evidence": [ev("M", MQ["afew"]), ev("M", MQ["afew_frag"])],
    },
    {
        "query_id": "X066",
        "reason": ("The query asks which modifiers the documents exemplify for the dependent form "
                   "\\mention{no}. Only \\mention{practically no} is written out; \\mention{almost} "
                   "is reported to be permitted by both \\mention{no} and \\mention{none}, but the "
                   "sequence \\mention{almost no} named in the query does not itself appear in "
                   "either document. The record is licensed, with that difference carried in a "
                   "condition."),
        "evidence": [ev("M", MQ["approx_list"]), ev("M", MQ["nonone"])],
    },
    {
        "query_id": "X067",
        "reason": ("Function split not representable. The documents distinguish the dependent form "
                   "\\mention{no} from the independent form \\mention{none} and state that the "
                   "partitive requires the independent form, but the construction vocabulary "
                   "carries no dependent/independent parameter for peripheral modification (and "
                   "independent_argument merges subject, object and complement-of-preposition "
                   "uses), so the no/none function split can ride only in conditions. The record "
                   "also reports \\mention{almost} with \\mention{none} on the strength of the "
                   "statement that both forms permit \\mention{almost}; the sequence "
                   "\\mention{almost none} is not itself written out in either document. "
                   "Grounding limitation, unresolved: the sentence that licenses this cell says "
                   "nothing about attachment, and no statement anywhere is specific to "
                   "\\mention{none}. The peripheral_mod_admission classification, which requires "
                   "attachment outside the phrase's own determiner and internal nominal "
                   "dependents, therefore rests on the manuscript's general analysis of "
                   "approximatives, stated in §\\ref{sec:payne} and illustrated with "
                   "\\mention{almost every}; that same analysis requires internal attachment for "
                   "approximatives on externally determined independent cardinals, as in "
                   "\\mention{the almost thirty who came}. No none-specific attachment claim is "
                   "asserted in the record."),
        "evidence": [ev("M", MQ["nonone"]), ev("M", MQ["nonone_part"]),
                     ev("M", MQ["periph_def"]), ev("M", MQ["fig_every"]),
                     ev("M", MQ["thirty"])],
    },
    {
        "query_id": "X075",
        "reason": ("Attribution and cause. The status \"excluded\" reports CGEL's judgment on "
                   "\\mention{some a great deal better proposals}, but the manuscript's caveat is "
                   "that the excluded example also juxtaposes \\mention{some} and \\mention{a} and "
                   "so doesn't isolate NP category as the cause; CGEL permits \\mention{She's a lot "
                   "better player than me}. The status field carries the judgment but not the "
                   "caveat, which is recorded in conditions."),
        "evidence": [ev("M", MQ["deal_contrast"]), ev("M", MQ["deal_caveat"]),
                     ev("M", MQ["lot_better"])],
    },
    {
        "query_id": "X103",
        "reason": ("Scope caveat not representable in the record shape. The manuscript's fragment "
                   "places predication beyond its scope, while §2.3 cites predicative "
                   "\\mention{several} as evidence, so records built on predicative_complement "
                   "(X103-X105) rest on the profile discussion rather than on the fragment's use "
                   "permissions. The caveat is carried in conditions; the status field cannot "
                   "express it. See the predication_outside_fragment scope check."),
        "evidence": [ev("M", MQ["fragment_scope"]), ev("M", MQ["predicative"]),
                     ev("M", MQ["fragment_covers"])],
    },
    {
        "query_id": "X108",
        "reason": ("Category label partly inferred from section framing. The manuscript contrasts "
                   "attributive \\mention{numerous} with determinative \\mention{many} in a section "
                   "headed \"Quantificational adjectives and nominal independence\" and uses the "
                   "degree-modification contrast to separate them, but neither document contains a "
                   "sentence of the form \"numerous is an adjective\". The record states the "
                   "adjective categorization as the section's framing together with the stated "
                   "syntactic contrast, rather than as a quoted categorial assignment."),
        "evidence": [ev("M", MQ["quant_adj_head"]), ev("M", MQ["many_numerous"]),
                     ev("M", MQ["numerous_so"])],
    },
    {
        "query_id": "X110",
        "reason": ("Evidential and inferential limits. The cell is a constructed comparison built "
                   "on CGEL's adjective-fusion statement, and the manuscript includes it precisely "
                   "as a control: existential occurrence doesn't decide the structural analysis. "
                   "The displaced-subject analysis presupposed by the construction id is CGEL's, so "
                   "this record reports participation only and supports no inference to category or "
                   "Head relations. The record shape has no field for that distinction, so it is "
                   "carried in conditions."),
        "evidence": [ev("M", MQ["second"]), ev("M", MQ["exist_nodecide"]),
                     ev("M", MQ["exist_several"])],
    },
]

records = {
    "lexemes": lexemes,
    "constructions": constructions,
    "participation_claims": participation,
    "scope_checks": scope_checks,
}

# ------------------------------------------------------------- validation ---
errors = []


def check_quotes(evs, where):
    for e in evs:
        text = SRC[e["source_id"]]
        if not e["quote"]:
            errors.append("%s: empty quote" % where)
        elif e["quote"] not in text:
            errors.append("%s: quote not in %s: %r" % (where, e["source_id"], e["quote"][:100]))


for c in participation:
    check_quotes(c["evidence"], c["id"])
    if c["status"] == "not_stated" and (c["conditions"] or c["evidence"]):
        errors.append("%s: not_stated must have empty conditions and evidence" % c["id"])
    if c["status"] != "not_stated" and not c["evidence"]:
        errors.append("%s: missing evidence" % c["id"])
for s in scope_checks:
    check_quotes(s["evidence"], s["id"])
for x in exceptions:
    check_quotes(x["evidence"], "exception " + x["query_id"])
    if x["query_id"] not in QUERIES:
        errors.append("exception %s: unknown query id" % x["query_id"])

ids = [c["id"] for c in participation]
if ids != ["X%03d" % i for i in range(1, 111)]:
    errors.append("participation ids wrong")
for c in participation:
    q = QUERIES[c["id"]]
    for field in ("lexeme_id", "form", "construction_id"):
        if c[field] != q[field]:
            errors.append("%s: %s mismatch %r vs query %r" % (c["id"], field, c[field], q[field]))
if [l["id"] for l in lexemes] != TASK["lexeme_ids"]:
    errors.append("lexeme ids mismatch")
if [s["id"] for s in scope_checks] != list(TASK["scope_checks"].keys()):
    errors.append("scope check ids mismatch")

schema = TASK["output_schema"]


def validate(obj, sch, path):
    t = sch.get("type")
    if t == "object":
        if not isinstance(obj, dict):
            errors.append("%s: not object" % path)
            return
        for k in sch.get("required", []):
            if k not in obj:
                errors.append("%s: missing %s" % (path, k))
        for k, v in obj.items():
            if k not in sch.get("properties", {}):
                errors.append("%s: extra key %s" % (path, k))
            else:
                validate(v, sch["properties"][k], path + "/" + k)
    elif t == "array":
        if not isinstance(obj, list):
            errors.append("%s: not array" % path)
            return
        for i, item in enumerate(obj):
            validate(item, sch["items"], "%s[%d]" % (path, i))
    elif t == "string":
        if not isinstance(obj, str):
            errors.append("%s: not string" % path)
        elif "enum" in sch and obj not in sch["enum"]:
            errors.append("%s: %r not in enum" % (path, obj))


validate(records, schema, "")
with open(os.path.join(ROOT, "schema.json"), encoding="utf-8") as fh:
    validate(records, json.load(fh), "(schema.json)")

if errors:
    print("VALIDATION ERRORS (%d):" % len(errors))
    for e in errors[:80]:
        print(" -", e)
    sys.exit(1)

with open(os.path.join(ROOT, "records.json"), "w", encoding="utf-8") as fh:
    json.dump(records, fh, indent=2, ensure_ascii=False)
    fh.write("\n")
with open(os.path.join(ROOT, "exceptions.json"), "w", encoding="utf-8") as fh:
    json.dump(exceptions, fh, indent=2, ensure_ascii=False)
    fh.write("\n")

from collections import Counter
print("ok: %d lexemes, %d constructions, %d claims, %d scope checks, %d exceptions"
      % (len(lexemes), len(constructions), len(participation), len(scope_checks), len(exceptions)))
print(Counter(c["status"] for c in participation))
